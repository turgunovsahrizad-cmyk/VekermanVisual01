package dev.vekerman.visual.mixin;

import dev.vekerman.visual.HitColor;
import dev.vekerman.visual.Hooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** HitColor: draw the armor with the "hurt" overlay while a just-hit entity is being rendered. */
@Mixin(net.minecraft.client.render.entity.equipment.EquipmentRenderer.class)
public abstract class EquipmentRendererMixin {
    @ModifyArg(method = "render(Lnet/minecraft/client/render/entity/equipment/EquipmentModel$LayerType;Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/client/model/Model;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/Model;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V"),
            index = 3)
    private int vv$overlay(int overlay) {
        Hooks.armorMixinSeen = true;
        return Hooks.armorHurt ? HitColor.hurtOverlay() : overlay;
    }
}
