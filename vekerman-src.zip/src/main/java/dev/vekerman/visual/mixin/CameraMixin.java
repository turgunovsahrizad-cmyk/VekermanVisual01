package dev.vekerman.visual.mixin;

import dev.vekerman.visual.FreeLook;
import dev.vekerman.visual.Hooks;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Free Look: the camera uses its own rotation while the key is held. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @ModifyVariable(method = "setRotation(FF)V", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float vv$yaw(float yaw) {
        Hooks.camHooked = true;
        return FreeLook.active ? FreeLook.yaw : yaw;
    }

    @ModifyVariable(method = "setRotation(FF)V", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private float vv$pitch(float pitch) {
        return FreeLook.active ? FreeLook.pitch : pitch;
    }
}
