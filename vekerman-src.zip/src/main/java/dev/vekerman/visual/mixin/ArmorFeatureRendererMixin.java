package dev.vekerman.visual.mixin;

import dev.vekerman.visual.HitColor;
import dev.vekerman.visual.Hooks;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** HitColor: remember whether the entity whose armor is drawn right now was just hit. */
@Mixin(ArmorFeatureRenderer.class)
public abstract class ArmorFeatureRendererMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void vv$begin(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                          BipedEntityRenderState state, float limbAngle, float limbDistance, CallbackInfo ci) {
        Hooks.armorHurt = state.hurt && HitColor.armorEnabled();
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void vv$end(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                        BipedEntityRenderState state, float limbAngle, float limbDistance, CallbackInfo ci) {
        Hooks.armorHurt = false;
    }
}
