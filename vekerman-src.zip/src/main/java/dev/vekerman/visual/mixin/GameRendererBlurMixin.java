package dev.vekerman.visual.mixin;

import dev.vekerman.visual.Hooks;
import dev.vekerman.visual.MotionBlur;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Motion blur hook: runs right after the 3D world is drawn, before the HUD. */
@Mixin(GameRenderer.class)
public abstract class GameRendererBlurMixin {
    @Inject(method = "renderWorld", at = @At("TAIL"))
    private void vv$blur(RenderTickCounter tickCounter, CallbackInfo ci) {
        Hooks.blurHooked = true;
        MotionBlur.apply();
    }
}
