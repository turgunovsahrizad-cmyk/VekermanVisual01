package dev.vekerman.visual.mixin;

import dev.vekerman.visual.FreeLook;
import dev.vekerman.visual.Hooks;
import net.minecraft.client.Mouse;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Free Look: mouse / touch movement turns the camera instead of the player. */
@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Redirect(method = "updateMouse", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"))
    private void vv$look(ClientPlayerEntity player, double dx, double dy) {
        Hooks.mouseHooked = true;
        if (FreeLook.active) FreeLook.turn(dx, dy);
        else player.changeLookDirection(dx, dy);
    }
}
