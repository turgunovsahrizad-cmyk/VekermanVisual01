package dev.vekerman.visual.mixin;

import dev.vekerman.visual.EntityCulling;
import dev.vekerman.visual.Hooks;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Entity Culling: do not render entities that are hidden behind blocks. */
@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <E extends Entity> void vv$cull(E entity, Frustum frustum, double x, double y, double z,
                                            CallbackInfoReturnable<Boolean> cir) {
        Hooks.cullHooked = true;
        if (EntityCulling.shouldHide(entity)) cir.setReturnValue(false);
    }
}
