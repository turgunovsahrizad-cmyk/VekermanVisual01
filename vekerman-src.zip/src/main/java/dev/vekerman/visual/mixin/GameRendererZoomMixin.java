package dev.vekerman.visual.mixin;

import dev.vekerman.visual.Hooks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Zoom without the vanilla FOV limit of 30. */
@Mixin(GameRenderer.class)
public abstract class GameRendererZoomMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void vv$fov(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Float> cir) {
        Hooks.fovHooked = true;
        double z = Hooks.zoomFactor;
        if (z > 1.001) {
            cir.setReturnValue(Math.max(3.0f, cir.getReturnValue() / (float) z));
        }
    }
}
