package dev.vekerman.visual;

import net.minecraft.client.gui.DrawContext;

/** Small drawing helpers: rounded rectangles, pixel icons, toggle switch. */
public class Draw {
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
        c.fill(x, y + r, x + w, y + h - r, color);
    }

    /** filled rounded rect with a 1px border */
    public static void card(DrawContext c, int x, int y, int w, int h, int r, int border, int fill) {
        rrect(c, x, y, w, h, r, border);
        rrect(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    public static void bitmap(DrawContext c, String[] rows, int x, int y, int color) {
        for (int j = 0; j < rows.length; j++) {
            String row = rows[j];
            for (int i = 0; i < row.length(); i++) {
                if (row.charAt(i) == '#') c.fill(x + i, y + j, x + i + 1, y + j + 1, color);
            }
        }
    }

    private static final String[] GEAR = {
            "....#....",
            ".#.###.#.",
            "..#####..",
            ".##...##.",
            "###...###",
            ".##...##.",
            "..#####..",
            ".#.###.#.",
            "....#...."};

    private static final String[] DIAMOND = {
            "..#..",
            ".###.",
            "#####",
            ".###.",
            "..#.."};

    private static final String[][] ICONS = {
            // Combat
            {"#.....#", "##...##", ".##.##.", "..###..", ".##.##.", "##...##", "#.....#"},
            // Movement
            {"...#...", "....#..", "#######", "....#..", "...#...", ".......", "......."},
            // Visual
            {".......", "..###..", ".#...#.", "#..#..#", ".#...#.", "..###..", "......."},
            // HUD
            {"#######", "#.....#", "#.###.#", "#.....#", "#.##..#", "#.....#", "#######"},
            // Utilities
            {"....##.", "...#.#.", "...##..", "..#....", ".#.....", "#......", "......."},
            // Config
            {"#######", "..#....", "..#....", "#######", "....#..", "....#..", "#######"}};

    public static void gear(DrawContext c, int x, int y, int color) {
        bitmap(c, GEAR, x, y, color);
    }

    public static void tabIcon(DrawContext c, int tab, int x, int y, int color) {
        if (tab >= 0 && tab < ICONS.length) bitmap(c, ICONS[tab], x, y, color);
    }

    public static void logo(DrawContext c, int x, int y, int color) {
        bitmap(c, DIAMOND, x + 3, y, color);
        bitmap(c, DIAMOND, x, y + 4, color);
        bitmap(c, DIAMOND, x + 6, y + 4, color);
        bitmap(c, DIAMOND, x + 3, y + 8, color);
    }

    /** 22 x 11 toggle switch */
    public static void toggle(DrawContext c, int x, int y, boolean on, int accent) {
        rrect(c, x, y, 22, 11, 5, on ? accent : 0xFF3A3A44);
        int kx = on ? x + 12 : x + 1;
        rrect(c, kx, y + 1, 9, 9, 4, on ? 0xFFE9DDFF : 0xFF8E8E9A);
    }
}
