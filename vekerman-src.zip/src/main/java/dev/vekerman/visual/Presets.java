package dev.vekerman.visual;

/**
 * The three built-in presets. IMPORTANT: the real private configs of these creators are not public,
 * so these are editable approximations. Change them in-game and use [+ Add Config] to keep your own copy.
 */
public class Presets {
    public static final String[] NAMES = {"Fluger CFG", "Akvych CFG", "IlaStudio CFG"};

    public static Config.Settings build(String name) {
        Config.Settings s = Config.defaults();
        if (name.equals(NAMES[0])) fluger(s);
        else if (name.equals(NAMES[1])) akvych(s);
        else ilastudio(s);
        return s;
    }

    private static void m(Config.Settings s, String id, boolean on, int key, int x, int y, double scale) {
        Config.Mod m = s.mods.get(id);
        m.enabled = on;
        m.key = key;
        m.x = x;
        m.y = y;
        m.n.put("scale", scale);
    }

    private static void en(Config.Settings s, String id, boolean on, int key) {
        Config.Mod m = s.mods.get(id);
        m.enabled = on;
        m.key = key;
    }

    private static void fluger(Config.Settings s) {
        s.hudColor = "Purple";
        s.hudOpacity = 0.55;
        m(s, "fps", true, -1, 6, 6, 1.0);
        m(s, "cps", true, -1, 6, 24, 1.0);
        m(s, "ping", true, -1, 6, 42, 1.0);
        m(s, "coords", true, -1, 6, 60, 1.0);
        m(s, "keystrokes", true, -1, 6, 84, 1.0);
        m(s, "armorhud", true, -1, 400, 6, 1.0);
        m(s, "potionhud", true, -1, 400, 80, 1.0);
        en(s, "zoom", true, 67);        // C
        en(s, "fullbright", true, 66);  // B
        en(s, "autosprint", true, -1);
        en(s, "waypoints", true, -1);
        en(s, "nametag", true, -1);
        en(s, "damageindicator", true, -1);
        en(s, "fpsboost", true, -1);
        s.optb.put("smoothFps", true);
        s.optn.put("fpsCap", 144.0);
        s.optn.put("particleLevel", 40.0);
    }

    private static void akvych(Config.Settings s) {
        s.hudColor = "Blue";
        s.hudOpacity = 0.45;
        m(s, "fps", true, -1, 6, 6, 0.9);
        m(s, "cps", true, -1, 6, 22, 0.9);
        m(s, "ping", false, -1, 6, 38, 0.9);
        m(s, "coords", false, -1, 6, 54, 0.9);
        m(s, "keystrokes", true, -1, 6, 76, 0.9);
        m(s, "armorhud", true, -1, 400, 6, 0.9);
        m(s, "potionhud", true, -1, 400, 70, 0.9);
        en(s, "zoom", true, 90);        // Z
        en(s, "fullbright", false, -1);
        en(s, "autosprint", true, -1);
        en(s, "waypoints", true, -1);
        en(s, "nametag", false, -1);
        en(s, "damageindicator", false, -1);
        en(s, "fpsboost", true, -1);
        s.optb.put("smoothFps", false);
        s.optn.put("particleLevel", 25.0);
    }

    private static void ilastudio(Config.Settings s) {
        s.hudColor = "Green";
        s.hudOpacity = 0.7;
        m(s, "fps", true, -1, 6, 6, 1.1);
        m(s, "cps", true, -1, 6, 28, 1.1);
        m(s, "ping", true, -1, 6, 50, 1.1);
        m(s, "coords", true, -1, 6, 72, 1.1);
        m(s, "keystrokes", true, -1, 6, 100, 1.1);
        m(s, "armorhud", true, -1, 400, 6, 1.1);
        m(s, "potionhud", true, -1, 400, 90, 1.1);
        en(s, "zoom", true, 67);
        en(s, "fullbright", true, 71);  // G
        en(s, "autosprint", false, -1);
        en(s, "waypoints", true, -1);
        en(s, "nametag", true, -1);
        en(s, "damageindicator", true, -1);
        en(s, "fpsboost", true, -1);
        s.optb.put("smoothFps", true);
        s.optn.put("fpsCap", 120.0);
        s.optn.put("particleLevel", 60.0);
    }
}
