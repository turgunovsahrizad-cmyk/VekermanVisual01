package dev.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;

import java.lang.reflect.Field;

/** Recolors the red "entity was hit" overlay by rewriting the overlay texture. No mixin needed. */
public class HitColor {
    public static final String[] NAMES = {"Red", "Blue", "Green", "Purple", "Yellow", "White", "Cyan", "Orange"};
    private static final int[] RGB = {0xFF0000, 0x3B82F6, 0x22C55E, 0x8B5CF6, 0xFACC15, 0xFFFFFF, 0x22D3EE, 0xF97316};
    private static final int DEFAULT = 0xB2FF0000;

    private static int applied = DEFAULT;
    private static Field field;
    private static boolean failed = false;

    private static int wanted() {
        String c = Config.str("hitcolor", "color");
        int rgb = RGB[0];
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equals(c)) rgb = RGB[i];
        int a = (int) Math.round(Math.max(0.2, Math.min(1.0, Config.num("hitcolor", "opacity"))) * 255);
        return (a << 24) | rgb;
    }

    public static void update(MinecraftClient mc) {
        if (failed) return;
        int want = Config.on("hitcolor") ? wanted() : DEFAULT;
        if (want == applied) return;
        try {
            OverlayTexture ot = mc.gameRenderer.getOverlayTexture();
            if (field == null) {
                for (Field f : OverlayTexture.class.getDeclaredFields()) {
                    if (f.getType() == NativeImageBackedTexture.class) {
                        f.setAccessible(true);
                        field = f;
                    }
                }
            }
            if (field == null) {
                failed = true;
                return;
            }
            NativeImageBackedTexture tex = (NativeImageBackedTexture) field.get(ot);
            NativeImage img = tex.getImage();
            if (img == null) return;
            for (int y = 0; y < 8; y++) for (int x = 0; x < 16; x++) img.setColorArgb(x, y, want);
            tex.upload();
            applied = want;
        } catch (Throwable t) {
            failed = true;
        }
    }
}
