package dev.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public class Hud {
    /** id -> {x, y, w, h} (screen pixels) of every HUD element drawn this frame; used for dragging */
    public static final Map<String, int[]> bounds = new LinkedHashMap<>();

    public static class Alert {
        public final RegistryEntry<StatusEffect> effect;
        public final long start;

        public Alert(RegistryEntry<StatusEffect> effect, long start) {
            this.effect = effect;
            this.start = start;
        }
    }

    public static class Dmg {
        public final Vec3d pos;
        public final float amount;
        public final long start;

        public Dmg(Vec3d pos, float amount, long start) {
            this.pos = pos;
            this.amount = amount;
            this.start = start;
        }
    }

    public static final List<Alert> alerts = new ArrayList<>();
    public static final List<Dmg> damage = new ArrayList<>();

    private static long lastFrame = System.nanoTime();
    private static int W, H;
    private static boolean editing;

    // projection state (rebuilt every frame)
    private static boolean projReady;
    private static Vec3d camPos, fwd, right, up;
    private static double th, aspect;

    public static String hit(int x, int y) {
        for (Map.Entry<String, int[]> e : bounds.entrySet()) {
            int[] b = e.getValue();
            if (x >= b[0] - 2 && x <= b[0] + b[2] + 2 && y >= b[1] - 2 && y <= b[1] + b[3] + 2) return e.getKey();
        }
        return null;
    }

    private static int bg() {
        int a = (int) Math.round(Math.max(0.05, Math.min(1.0, Config.cur.hudOpacity)) * 255);
        return a << 24;
    }

    private static int accentA(int alpha) {
        return (alpha << 24) | (Config.accent() & 0xFFFFFF);
    }

    // ------------------------------------------------------------------ frame

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        float dt = (float) Math.min(0.1, (now - lastFrame) / 1.0e9);
        lastFrame = now;

        Modules.pollMouse(mc);
        Modules.frame(mc, dt);
        bounds.clear();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        W = mc.getWindow().getScaledWidth();
        H = mc.getWindow().getScaledHeight();
        editing = mc.currentScreen instanceof ClickGui;
        TextRenderer tr = mc.textRenderer;
        setupProjection(mc);

        if (Config.on("waypoints")) drawWaypoints(ctx, tr, mc);
        if (Config.on("nametag")) drawNameTags(ctx, tr, mc);
        if (Config.on("damageindicator")) drawDamage(ctx, tr);

        if (Config.on("fps")) pill(ctx, tr, "fps", "FPS " + mc.getCurrentFps());
        if (Config.on("cps")) pill(ctx, tr, "cps", "CPS " + Modules.cpsLeft() + " | " + Modules.cpsRight());
        if (Config.on("ping")) pill(ctx, tr, "ping", "Ping " + Modules.ping(mc) + "ms");
        if (Config.on("coords")) {
            pill(ctx, tr, "coords", String.format(Locale.ROOT, "XYZ %.0f %.0f %.0f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (Config.on("keystrokes")) keystrokes(ctx, tr, mc);
        if (Config.on("armorhud")) armor(ctx, tr, mc);
        if (Config.on("potionhud")) {
            potions(ctx, tr, mc);
            drawAlerts(ctx);
        }
    }

    // ------------------------------------------------------------------ element frame

    private static void begin(DrawContext ctx, String id, int w, int h) {
        Config.Mod m = Config.mod(id);
        float s = (float) Config.num(id, "scale");
        int sw = (int) (w * s);
        int sh = (int) (h * s);
        int x = Math.max(0, Math.min(m.x, Math.max(0, W - sw)));
        int y = Math.max(0, Math.min(m.y, Math.max(0, H - sh)));
        ctx.getMatrices().push();
        ctx.getMatrices().translate((float) x, (float) y, 0f);
        ctx.getMatrices().scale(s, s, 1f);
        bounds.put(id, new int[]{x, y, sw, sh});
    }

    private static void end(DrawContext ctx) {
        ctx.getMatrices().pop();
    }

    private static void pill(DrawContext ctx, TextRenderer tr, String id, String text) {
        int w = tr.getWidth(text) + 10;
        int h = 14;
        begin(ctx, id, w, h);
        Draw.rrect(ctx, 0, 0, w, h, 3, bg());
        ctx.fill(0, 2, 2, h - 2, Config.accent());
        ctx.drawText(tr, text, 6, 3, 0xFFFFFFFF, true);
        end(ctx);
    }

    private static void placeholder(DrawContext ctx, TextRenderer tr, String id, String label) {
        int w = tr.getWidth(label) + 10;
        begin(ctx, id, w, 14);
        Draw.rrect(ctx, 0, 0, w, 14, 3, 0x66000000);
        ctx.drawText(tr, label, 5, 3, 0xFF9A9AB0, false);
        end(ctx);
    }

    // ------------------------------------------------------------------ keystrokes

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                            String label, String sub, boolean pressed) {
        Draw.rrect(ctx, x, y, w, h, 3, pressed ? accentA(0xDD) : bg());
        int fg = 0xFFFFFFFF;
        if (sub == null) {
            ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, fg, false);
        } else {
            ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + 3, fg, false);
            ctx.drawText(tr, sub, x + (w - tr.getWidth(sub)) / 2, y + 12, fg, false);
        }
    }

    private static void keystrokes(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        GameOptions o = mc.options;
        int s = 22;
        int g = 2;
        int total = 3 * s + 2 * g;
        int bw = (total - g) / 2;
        int y3 = 2 * (s + g);
        int y4 = y3 + s + g;
        int sh = 9;
        begin(ctx, "keystrokes", total, y4 + sh);

        key(ctx, tr, s + g, 0, s, s, "W", null, o.forwardKey.isPressed());
        key(ctx, tr, 0, s + g, s, s, "A", null, o.leftKey.isPressed());
        key(ctx, tr, s + g, s + g, s, s, "S", null, o.backKey.isPressed());
        key(ctx, tr, 2 * (s + g), s + g, s, s, "D", null, o.rightKey.isPressed());
        key(ctx, tr, 0, y3, bw, s, "LMB", String.valueOf(Modules.cpsLeft()), o.attackKey.isPressed());
        key(ctx, tr, bw + g, y3, total - bw - g, s, "RMB", String.valueOf(Modules.cpsRight()), o.useKey.isPressed());

        boolean sp = o.jumpKey.isPressed();
        Draw.rrect(ctx, 0, y4, total, sh, 3, sp ? accentA(0xDD) : bg());
        ctx.fill(total / 2 - 10, y4 + 4, total / 2 + 10, y4 + 5, 0xFFFFFFFF);
        end(ctx);
    }

    // ------------------------------------------------------------------ armor

    private static void armor(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        List<ItemStack> items = new ArrayList<>();
        for (EquipmentSlot sl : slots) {
            ItemStack st = mc.player.getEquippedStack(sl);
            if (!st.isEmpty()) items.add(st);
        }
        if (items.isEmpty()) {
            if (editing) placeholder(ctx, tr, "armorhud", "Armor HUD");
            return;
        }
        boolean horizontal = Config.str("armorhud", "layout").equals("Horizontal");
        int pw = tr.getWidth("100%");
        if (!horizontal) {
            int w = 22 + pw;
            int h = items.size() * 18 + 2;
            begin(ctx, "armorhud", w, h);
            Draw.rrect(ctx, 0, 0, w, h, 3, bg());
            for (int i = 0; i < items.size(); i++) {
                ItemStack st = items.get(i);
                ctx.drawItem(st, 2, 2 + i * 18);
                String t = durability(st);
                ctx.drawText(tr, t, 22, 6 + i * 18, durColor(st), true);
            }
            end(ctx);
        } else {
            int col = Math.max(16, pw) + 4;
            int w = items.size() * col;
            int h = 28;
            begin(ctx, "armorhud", w, h);
            Draw.rrect(ctx, 0, 0, w, h, 3, bg());
            for (int i = 0; i < items.size(); i++) {
                ItemStack st = items.get(i);
                int cx = i * col;
                ctx.drawItem(st, cx + (col - 16) / 2, 2);
                String t = durability(st);
                ctx.drawText(tr, t, cx + (col - tr.getWidth(t)) / 2, 19, durColor(st), true);
            }
            end(ctx);
        }
    }

    private static int percent(ItemStack st) {
        int max = st.getMaxDamage();
        if (max <= 0) return 100;
        return Math.max(0, Math.min(100, Math.round(100f * (max - st.getDamage()) / max)));
    }

    private static String durability(ItemStack st) {
        return st.isDamageable() ? percent(st) + "%" : "";
    }

    private static int durColor(ItemStack st) {
        int p = percent(st);
        if (p > 50) return 0xFF55FF55;
        if (p > 25) return 0xFFFFFF55;
        return 0xFFFF5555;
    }

    // ------------------------------------------------------------------ potions

    public static void effectIcon(DrawContext ctx, RegistryEntry<StatusEffect> e, int x, int y, int size, int color) {
        Optional<RegistryKey<StatusEffect>> k = e.getKey();
        if (k.isEmpty()) return;
        Identifier id = k.get().getValue();
        Identifier sprite = Identifier.of(id.getNamespace(), "mob_effect/" + id.getPath());
        ctx.drawGuiTexture(RenderLayer::getGuiTextured, sprite, x, y, size, size, color);
    }

    private static String time(StatusEffectInstance ei) {
        if (ei.isInfinite()) return "**:**";
        int sec = Math.max(0, ei.getDuration() / 20);
        return (sec / 60) + ":" + String.format(Locale.ROOT, "%02d", sec % 60);
    }

    private static String effectName(StatusEffectInstance ei) {
        String n = ei.getEffectType().value().getName().getString();
        return ei.getAmplifier() > 0 ? n + " " + (ei.getAmplifier() + 1) : n;
    }

    private static void potions(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        Collection<StatusEffectInstance> effs = mc.player.getStatusEffects();
        if (effs.isEmpty()) {
            if (editing) placeholder(ctx, tr, "potionhud", "Potion HUD");
            return;
        }
        boolean horizontal = Config.str("potionhud", "layout").equals("Horizontal");
        if (!horizontal) {
            int tw = 0;
            for (StatusEffectInstance e : effs) tw = Math.max(tw, tr.getWidth(effectName(e) + "  " + time(e)));
            int w = 24 + tw + 4;
            int h = effs.size() * 20 + 2;
            begin(ctx, "potionhud", w, h);
            Draw.rrect(ctx, 0, 0, w, h, 3, bg());
            int i = 0;
            for (StatusEffectInstance e : effs) {
                effectIcon(ctx, e.getEffectType(), 3, 2 + i * 20, 18, 0xFFFFFFFF);
                ctx.drawText(tr, effectName(e), 24, 3 + i * 20, 0xFFFFFFFF, true);
                ctx.drawText(tr, time(e), 24, 12 + i * 20, 0xFFBBBBCC, true);
                i++;
            }
            end(ctx);
        } else {
            int col = 38;
            int w = effs.size() * col;
            int h = 32;
            begin(ctx, "potionhud", w, h);
            Draw.rrect(ctx, 0, 0, w, h, 3, bg());
            int i = 0;
            for (StatusEffectInstance e : effs) {
                effectIcon(ctx, e.getEffectType(), i * col + (col - 18) / 2, 3, 18, 0xFFFFFFFF);
                String t = time(e);
                ctx.drawText(tr, t, i * col + (col - tr.getWidth(t)) / 2, 21, 0xFFFFFFFF, true);
                i++;
            }
            end(ctx);
        }
    }

    /** icon under the crosshair when an effect has just run out: blinks, then fades away */
    private static void drawAlerts(DrawContext ctx) {
        if (alerts.isEmpty()) return;
        int size = (int) Config.num("potionhud", "alertsize");
        long now = System.currentTimeMillis();
        double dur = 2.6;
        Iterator<Alert> it = alerts.iterator();
        List<Alert> live = new ArrayList<>();
        while (it.hasNext()) {
            Alert a = it.next();
            if ((now - a.start) / 1000.0 > dur) it.remove();
            else live.add(a);
        }
        int n = live.size();
        int x = W / 2 - (n * (size + 4) - 4) / 2;
        int y = H / 2 + 14;
        for (Alert a : live) {
            double t = (now - a.start) / 1000.0;
            double blink = t < 2.0 ? 0.575 + 0.425 * Math.sin(t * Math.PI * 5.0) : 1.0;
            double fade = t > 2.0 ? Math.max(0, 1.0 - (t - 2.0) / (dur - 2.0)) : 1.0;
            int alpha = (int) Math.round(Math.max(0.04, Math.min(1.0, blink * fade)) * 255);
            effectIcon(ctx, a.effect, x, y, size, (alpha << 24) | 0xFFFFFF);
            x += size + 4;
        }
    }

    // ------------------------------------------------------------------ projection (world -> screen, no mixins needed)

    private static void setupProjection(MinecraftClient mc) {
        projReady = false;
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null) return;
        camPos = cam.getPos();
        fwd = Vec3d.fromPolar(cam.getPitch(), cam.getYaw());
        right = Vec3d.fromPolar(0.0f, cam.getYaw() + 90.0f);
        up = right.crossProduct(fwd);
        th = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        aspect = (double) W / (double) H;
        projReady = true;
    }

    /** returns {screenX, screenY, distance} or null when behind the camera */
    public static double[] project(Vec3d target) {
        if (!projReady) return null;
        Vec3d d = target.subtract(camPos);
        double z = d.dotProduct(fwd);
        if (z < 0.05) return null;
        double sx = W / 2.0 + (d.dotProduct(right) / z) / (th * aspect) * (W / 2.0);
        double sy = H / 2.0 - (d.dotProduct(up) / z) / th * (H / 2.0);
        return new double[]{sx, sy, d.length()};
    }

    private static void drawWaypoints(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        if (Config.waypoints.isEmpty()) return;
        String dim = Modules.dimension(mc);
        boolean showDist = Config.flag("waypoints", "dist");
        for (Config.Waypoint w : Config.waypoints) {
            if (!w.visible || !w.dim.equals(dim)) continue;
            double[] p = project(new Vec3d(w.x + 0.5, w.y + 1.0, w.z + 0.5));
            if (p == null) continue;
            if (p[0] < 4 || p[0] > W - 4 || p[1] < 12 || p[1] > H - 12) continue;
            int x = (int) p[0];
            int y = (int) p[1];
            ctx.fill(x - 3, y - 3, x + 4, y + 4, 0xFF000000);
            ctx.fill(x - 2, y - 2, x + 3, y + 3, w.color);
            ctx.drawText(tr, w.name, x - tr.getWidth(w.name) / 2, y - 14, w.color, true);
            if (showDist) {
                String d = (int) p[2] + "m";
                ctx.drawText(tr, d, x - tr.getWidth(d) / 2, y + 6, 0xFFDDDDDD, true);
            }
        }
    }

    private static void drawNameTags(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        double max = Config.num("nametag", "dist");
        boolean hp = Config.flag("nametag", "health");
        for (PlayerEntity pl : mc.world.getPlayers()) {
            if (pl == mc.player) continue;
            if (mc.player.distanceTo(pl) > max) continue;
            if (mc.player.canSee(pl) && !pl.isSneaking()) continue; // vanilla already draws a tag for visible players
            double[] p = project(new Vec3d(pl.getX(), pl.getY() + pl.getHeight() + 0.4, pl.getZ()));
            if (p == null || p[0] < 0 || p[0] > W || p[1] < 0 || p[1] > H) continue;
            String t = pl.getName().getString() + (hp ? " [" + (int) Math.ceil(pl.getHealth()) + "]" : "");
            int w = tr.getWidth(t) + 6;
            int x = (int) p[0] - w / 2;
            int y = (int) p[1] - 10;
            Draw.rrect(ctx, x, y, w, 11, 3, 0x88000000);
            ctx.drawText(tr, t, x + 3, y + 2, 0xFFFFFFFF, false);
        }
    }

    private static void drawDamage(DrawContext ctx, TextRenderer tr) {
        if (damage.isEmpty()) return;
        long now = System.currentTimeMillis();
        double dur = Config.num("damageindicator", "time");
        float size = (float) Config.num("damageindicator", "size");
        Iterator<Dmg> it = damage.iterator();
        while (it.hasNext()) {
            Dmg d = it.next();
            double t = (now - d.start) / 1000.0;
            if (t > dur) {
                it.remove();
                continue;
            }
            double[] p = project(d.pos.add(0, t * 0.6, 0));
            if (p == null) continue;
            int alpha = (int) Math.round(Math.max(0.05, 1.0 - t / dur) * 255);
            String s = String.format(Locale.ROOT, "-%.1f", d.amount);
            ctx.getMatrices().push();
            ctx.getMatrices().translate((float) p[0], (float) p[1], 0f);
            ctx.getMatrices().scale(size, size, 1f);
            ctx.drawText(tr, s, -tr.getWidth(s) / 2, 0, (alpha << 24) | 0xFF5555, true);
            ctx.getMatrices().pop();
        }
    }
}
