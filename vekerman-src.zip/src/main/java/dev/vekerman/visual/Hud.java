package dev.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Hud {
    /** id -> {x, y, w, h} (screen pixels) of every HUD element drawn this frame; used for dragging */
    public static final Map<String, int[]> bounds = new LinkedHashMap<>();


    private static long lastFrame = System.nanoTime();
    private static int W, H;
    private static boolean editing;

    public static String hit(int x, int y) {
        for (Map.Entry<String, int[]> e : bounds.entrySet()) {
            int[] b = e.getValue();
            if (x >= b[0] - 2 && x <= b[0] + b[2] + 2 && y >= b[1] - 2 && y <= b[1] + b[3] + 2) return e.getKey();
        }
        return null;
    }

    private static int bg() {
        int a = (int) Math.round(Math.max(0.05, Math.min(1.0, Config.cur.hudOpacity)) * 255);
        return a << 24;
    }

    private static int accentA(int alpha) {
        return (alpha << 24) | (Config.accent() & 0xFFFFFF);
    }

    // ------------------------------------------------------------------ frame

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        long t0 = System.nanoTime();
        try {
            renderInner(ctx);
        } finally {
            Perf.hud((System.nanoTime() - t0) / 1.0e6);
        }
    }

    private static void renderInner(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        float dt = (float) Math.min(0.1, (now - lastFrame) / 1.0e9);
        lastFrame = now;

        Modules.pollMouse(mc);
        Modules.frame(mc, dt);
        bounds.clear();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        W = mc.getWindow().getScaledWidth();
        H = mc.getWindow().getScaledHeight();
        editing = mc.currentScreen instanceof ClickGui;
        TextRenderer tr = mc.textRenderer;


        if (Config.on("fps")) pill(ctx, tr, "fps", "FPS " + mc.getCurrentFps());
        if (Config.on("cps")) pill(ctx, tr, "cps", "CPS " + Modules.cpsLeft() + " | " + Modules.cpsRight());
        if (Config.on("ping")) pill(ctx, tr, "ping", "Ping " + Modules.ping(mc) + "ms");
        if (Config.on("coords")) {
            pill(ctx, tr, "coords", String.format(Locale.ROOT, "XYZ %.0f %.0f %.0f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (Config.on("keystrokes")) keystrokes(ctx, tr, mc);
        if (Config.on("armorhud")) armor(ctx, tr, mc);
        if (Config.on("potionhud")) potions(ctx, tr, mc);
        if (Config.on("armorwarn")) armorWarn(ctx, tr, mc);
        if (Config.on("pvpcount")) pvpCounter(ctx, tr);
    }

    // ------------------------------------------------------------------ element frame

    private static void begin(DrawContext ctx, String id, int w, int h) {
        Config.Mod m = Config.mod(id);
        float s = id.equals("armorwarn") ? (float) Config.num(id, "isize") / 16f : (float) Config.num(id, "scale");
        if (s < 0.3f) s = 1f;
        int sw = (int) (w * s);
        int sh = (int) (h * s);
        int x;
        int y;
        if (m.x < 0 || m.y < 0) { // not moved yet: centered under the crosshair
            x = Math.max(0, (W - sw) / 2);
            y = Math.min(Math.max(0, H - sh), H / 2 + 14);
        } else {
            x = Math.max(0, Math.min(m.x, Math.max(0, W - sw)));
            y = Math.max(0, Math.min(m.y, Math.max(0, H - sh)));
        }
        ctx.getMatrices().push();
        ctx.getMatrices().translate((float) x, (float) y, 0f);
        ctx.getMatrices().scale(s, s, 1f);
        bounds.put(id, new int[]{x, y, sw, sh});
    }

    private static void end(DrawContext ctx) {
        ctx.getMatrices().pop();
    }

    private static void pill(DrawContext ctx, TextRenderer tr, String id, String text) {
        int w = tr.getWidth(text) + 10;
        int h = 14;
        begin(ctx, id, w, h);
        Draw.rrect(ctx, 0, 0, w, h, 3, bg());
        ctx.fill(0, 2, 2, h - 2, Config.accent());
        ctx.drawText(tr, text, 6, 3, 0xFFFFFFFF, true);
        end(ctx);
    }

    private static void placeholder(DrawContext ctx, TextRenderer tr, String id, String label) {
        int w = tr.getWidth(label) + 10;
        begin(ctx, id, w, 14);
        Draw.rrect(ctx, 0, 0, w, 14, 3, 0x66000000);
        ctx.drawText(tr, label, 5, 3, 0xFF9A9AB0, false);
        end(ctx);
    }

    // ------------------------------------------------------------------ keystrokes

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                            String label, String sub, boolean pressed) {
        Draw.rrect(ctx, x, y, w, h, 3, pressed ? accentA(0xDD) : bg());
        int fg = 0xFFFFFFFF;
        if (sub == null) {
            ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, fg, false);
        } else {
            ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + 3, fg, false);
            ctx.drawText(tr, sub, x + (w - tr.getWidth(sub)) / 2, y + 12, fg, false);
        }
    }

    private static void keystrokes(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        GameOptions o = mc.options;
        int s = 22;
        int g = 2;
        int total = 3 * s + 2 * g;
        int bw = (total - g) / 2;
        int y3 = 2 * (s + g);
        int y4 = y3 + s + g;
        int sh = 9;
        begin(ctx, "keystrokes", total, y4 + sh);

        key(ctx, tr, s + g, 0, s, s, "W", null, o.forwardKey.isPressed());
        key(ctx, tr, 0, s + g, s, s, "A", null, o.leftKey.isPressed());
        key(ctx, tr, s + g, s + g, s, s, "S", null, o.backKey.isPressed());
        key(ctx, tr, 2 * (s + g), s + g, s, s, "D", null, o.rightKey.isPressed());
        key(ctx, tr, 0, y3, bw, s, "LMB", String.valueOf(Modules.cpsLeft()), o.attackKey.isPressed());
        key(ctx, tr, bw + g, y3, total - bw - g, s, "RMB", String.valueOf(Modules.cpsRight()), o.useKey.isPressed());

        boolean sp = o.jumpKey.isPressed();
        Draw.rrect(ctx, 0, y4, total, sh, 3, sp ? accentA(0xDD) : bg());
        ctx.fill(total / 2 - 10, y4 + 4, total / 2 + 10, y4 + 5, 0xFFFFFFFF);
        end(ctx);
    }

    // ------------------------------------------------------------------ armor

    private static void armor(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        List<ItemStack> items = new ArrayList<>();
        for (EquipmentSlot sl : slots) {
            ItemStack st = mc.player.getEquippedStack(sl);
            if (!st.isEmpty()) items.add(st);
        }
        if (items.isEmpty()) {
            if (editing) placeholder(ctx, tr, "armorhud", "Armor HUD");
            return;
        }
        boolean horizontal = Config.str("armorhud", "layout").equals("Horizontal");
        int pw = tr.getWidth("100%");
        if (!horizontal) {
            int w = 22 + pw;
            int h = items.size() * 18 + 2;
            begin(ctx, "armorhud", w, h);
            Draw.rrect(ctx, 0, 0, w, h, 3, bg());
            for (int i = 0; i < items.size(); i++) {
                ItemStack st = items.get(i);
                ctx.drawItem(st, 2, 2 + i * 18);
                String t = durability(st);
                ctx.drawText(tr, t, 22, 6 + i * 18, durColor(st), true);
            }
            end(ctx);
        } else {
            int col = Math.max(16, pw) + 4;
            int w = items.size() * col;
            int h = 28;
            begin(ctx, "armorhud", w, h);
            Draw.rrect(ctx, 0, 0, w, h, 3, bg());
            for (int i = 0; i < items.size(); i++) {
                ItemStack st = items.get(i);
                int cx = i * col;
                ctx.drawItem(st, cx + (col - 16) / 2, 2);
                String t = durability(st);
                ctx.drawText(tr, t, cx + (col - tr.getWidth(t)) / 2, 19, durColor(st), true);
            }
            end(ctx);
        }
    }

    private static int percent(ItemStack st) {
        int max = st.getMaxDamage();
        if (max <= 0) return 100;
        return Math.max(0, Math.min(100, Math.round(100f * (max - st.getDamage()) / max)));
    }

    private static String durability(ItemStack st) {
        return st.isDamageable() ? percent(st) + "%" : "";
    }

    private static int durColor(ItemStack st) {
        int p = percent(st);
        if (p > 50) return 0xFF55FF55;
        if (p > 25) return 0xFFFFFF55;
        return 0xFFFF5555;
    }

    // ------------------------------------------------------------------ armor warning

    private static int warnMask = 0;

    private static void armorWarn(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        double threshold = Config.num("armorwarn", "threshold");
        boolean all = Config.str("armorwarn", "mode").equals("All broken");
        List<ItemStack> stacks = new ArrayList<>();
        List<Integer> pcts = new ArrayList<>();
        int mask = 0;
        for (int i = 0; i < slots.length; i++) {
            ItemStack st = mc.player.getEquippedStack(slots[i]);
            if (st.isEmpty() || !st.isDamageable()) continue;
            int p = percent(st);
            if (p <= threshold) {
                stacks.add(st);
                pcts.add(p);
                mask |= 1 << i;
            }
        }
        if (stacks.isEmpty()) {
            warnMask = 0;
            if (editing) placeholder(ctx, tr, "armorwarn", "Armor Warning");
            return;
        }
        if (!all) { // keep only the most broken part
            int best = 0;
            for (int i = 1; i < pcts.size(); i++) if (pcts.get(i) < pcts.get(best)) best = i;
            ItemStack s = stacks.get(best);
            int p = pcts.get(best);
            stacks.clear();
            pcts.clear();
            stacks.add(s);
            pcts.add(p);
        }
        // sound once when a part newly drops under the threshold
        if ((mask & ~warnMask) != 0 && Config.flag("armorwarn", "sound")) Modules.armorSound(mc);
        warnMask = mask;

        int cell = tr.getWidth("100%") + 6;
        int w = stacks.size() * cell;
        begin(ctx, "armorwarn", w, 26);
        for (int i = 0; i < stacks.size(); i++) {
            int x = i * cell;
            ctx.drawItem(stacks.get(i), x + (cell - 16) / 2, 0);
            String t = pcts.get(i) + "%";
            int col = pcts.get(i) <= 10 ? 0xFFFF5555 : 0xFFFFAA33;
            ctx.drawText(tr, t, x + (cell - tr.getWidth(t)) / 2, 17, col, false);
        }
        end(ctx);
    }

    // ------------------------------------------------------------------ potions (text only)

    private static String time(StatusEffectInstance ei) {
        if (ei.isInfinite()) return "**:**";
        int sec = Math.max(0, ei.getDuration() / 20);
        return (sec / 60) + ":" + String.format(Locale.ROOT, "%02d", sec % 60);
    }

    private static String effectName(StatusEffectInstance ei) {
        String n = ei.getEffectType().value().getName().getString();
        return ei.getAmplifier() > 0 ? n + " " + (ei.getAmplifier() + 1) : n;
    }

    private static void potions(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        Collection<StatusEffectInstance> effs = mc.player.getStatusEffects();
        if (effs.isEmpty()) {
            if (editing) placeholder(ctx, tr, "potionhud", "Potion HUD");
            return;
        }
        boolean horizontal = Config.str("potionhud", "layout").equals("Horizontal");
        if (!horizontal) {
            int nameW = 0;
            int timeW = 0;
            for (StatusEffectInstance e : effs) {
                nameW = Math.max(nameW, tr.getWidth(effectName(e)));
                timeW = Math.max(timeW, tr.getWidth(time(e)));
            }
            int w = nameW + timeW + 20;
            int h = effs.size() * 12 + 4;
            begin(ctx, "potionhud", w, h);
            Draw.rrect(ctx, 0, 0, w, h, 3, bg());
            ctx.fill(0, 2, 2, h - 2, Config.accent());
            int i = 0;
            for (StatusEffectInstance e : effs) {
                ctx.drawText(tr, effectName(e), 6, 3 + i * 12, 0xFFFFFFFF, true);
                String t = time(e);
                ctx.drawText(tr, t, w - 6 - tr.getWidth(t), 3 + i * 12, 0xFFBBBBCC, true);
                i++;
            }
            end(ctx);
        } else {
            List<String> names = new ArrayList<>();
            List<String> times = new ArrayList<>();
            int w = 0;
            for (StatusEffectInstance e : effs) {
                names.add(effectName(e));
                times.add(time(e));
                w += Math.max(tr.getWidth(effectName(e)), tr.getWidth(time(e))) + 10;
            }
            int h = 24;
            begin(ctx, "potionhud", w, h);
            Draw.rrect(ctx, 0, 0, w, h, 3, bg());
            ctx.fill(0, 2, 2, h - 2, Config.accent());
            int x = 0;
            for (int i = 0; i < names.size(); i++) {
                int cw = Math.max(tr.getWidth(names.get(i)), tr.getWidth(times.get(i))) + 10;
                ctx.drawText(tr, names.get(i), x + (cw - tr.getWidth(names.get(i))) / 2, 3, 0xFFFFFFFF, true);
                ctx.drawText(tr, times.get(i), x + (cw - tr.getWidth(times.get(i))) / 2, 13, 0xFFBBBBCC, true);
                x += cw;
            }
            end(ctx);
        }
    }

    // ------------------------------------------------------------------ PvP counter

    private static ItemStack sTotem, sGapple, sPearl, sPotion;

    private static void pvpCounter(DrawContext ctx, TextRenderer tr) {
        if (sTotem == null) {
            sTotem = new ItemStack(Items.TOTEM_OF_UNDYING);
            sGapple = new ItemStack(Items.GOLDEN_APPLE);
            sPearl = new ItemStack(Items.ENDER_PEARL);
            sPotion = new ItemStack(Items.SPLASH_POTION);
        }
        List<ItemStack> icons = new ArrayList<>();
        List<Integer> counts = new ArrayList<>();
        if (Config.flag("pvpcount", "totem")) {
            icons.add(sTotem);
            counts.add(Modules.totems);
        }
        if (Config.flag("pvpcount", "gapple")) {
            icons.add(sGapple);
            counts.add(Modules.gapples);
        }
        if (Config.flag("pvpcount", "pearl")) {
            icons.add(sPearl);
            counts.add(Modules.pearls);
        }
        if (Config.flag("pvpcount", "potion")) {
            icons.add(sPotion);
            counts.add(Modules.potions);
        }
        if (icons.isEmpty()) return;
        int cell = 26;
        int w = icons.size() * cell + 4;
        begin(ctx, "pvpcount", w, 28);
        Draw.rrect(ctx, 0, 0, w, 28, 3, bg());
        for (int i = 0; i < icons.size(); i++) {
            int x = 2 + i * cell;
            ctx.drawItem(icons.get(i), x + 5, 2);
            String t = String.valueOf(counts.get(i));
            int col = counts.get(i) == 0 ? 0xFFFF6666 : 0xFFFFFFFF;
            ctx.drawText(tr, t, x + (cell - tr.getWidth(t)) / 2, 19, col, true);
        }
        end(ctx);
    }
}
