package dev.vekerman.visual;

import com.mojang.blaze3d.platform.GlStateManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

/**
 * Turn-speed motion blur.
 * - only the 3D world is blurred (the hook runs before the HUD is drawn), HUD / inventory / chat are never touched;
 * - nothing is drawn while the camera is still (no cost, no ghosting), the blur grows with the turning speed
 *   and fades out right after the camera stops;
 * - blending goes through Minecraft's own GlStateManager and a texture unit Minecraft never uses, so the game's
 *   cached GL state stays correct (that was the cause of the see-through HUD before).
 * Any error switches the effect off for the session.
 */
public class MotionBlur {
    private static final int UNIT = 13; // texture unit that Minecraft does not use
    private static SimpleFramebuffer history;
    private static boolean historyValid = false;
    private static boolean failed = false;
    private static boolean glReady = false;
    private static int program, vao, vbo, uTex, uAlpha;

    private static float lastYaw, lastPitch, blendCur;
    private static boolean haveAngles = false;

    private static final String VS = "#version 150\nin vec2 pos;\nout vec2 uv;\nvoid main(){ uv = pos * 0.5 + 0.5; gl_Position = vec4(pos, 0.0, 1.0); }\n";
    private static final String FS = "#version 150\nuniform sampler2D tex;\nuniform float alpha;\nin vec2 uv;\nout vec4 frag;\nvoid main(){ frag = vec4(texture(tex, uv).rgb, alpha); }\n";

    public static void apply() {
        if (failed || !Config.on("motionblur")) {
            historyValid = false;
            blendCur = 0f;
            haveAngles = false;
            return;
        }
        long t0 = System.nanoTime();
        try {
            doApply();
        } catch (Throwable t) {
            failed = true;
        }
        Perf.blur((System.nanoTime() - t0) / 1.0e6);
    }

    /** 0 while the camera is still; grows with the turning speed; decays quickly after the camera stops */
    private static float updateBlend(MinecraftClient mc) {
        Camera cam = mc.gameRenderer.getCamera();
        float yaw = cam.getYaw();
        float pitch = cam.getPitch();
        float target = 0f;
        if (haveAngles && mc.currentScreen == null && mc.player != null) {
            float dy = ((yaw - lastYaw + 540f) % 360f) - 180f;
            float speed = Math.abs(dy) + Math.abs(pitch - lastPitch);
            if (speed > 0.25f) target = Math.min(1f, speed / 10f) * (float) Config.num("motionblur", "strength");
        }
        lastYaw = yaw;
        lastPitch = pitch;
        haveAngles = true;
        blendCur = mc.currentScreen != null ? 0f : Math.max(target, blendCur * 0.8f);
        return blendCur;
    }

    private static void doApply() {
        MinecraftClient mc = MinecraftClient.getInstance();
        float amount = updateBlend(mc);
        if (amount <= 0.02f) {
            historyValid = false; // camera is still: do nothing at all (no copy, no draw)
            return;
        }
        Framebuffer fb = mc.getFramebuffer();
        int w = fb.textureWidth;
        int h = fb.textureHeight;
        if (history == null) {
            history = new SimpleFramebuffer(w, h, false);
            historyValid = false;
        } else if (history.textureWidth != w || history.textureHeight != h) {
            history.resize(w, h);
            historyValid = false;
        }
        if (!glReady) initGl();

        if (historyValid) blend(fb, amount);

        // remember this frame for the next one
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, fb.fbo);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, history.fbo);
        GL30.glBlitFramebuffer(0, 0, w, h, 0, 0, w, h, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_NEAREST);
        fb.beginWrite(false);
        historyValid = true;
    }

    private static int compile(int type, String src) {
        int s = GL20.glCreateShader(type);
        GL20.glShaderSource(s, src);
        GL20.glCompileShader(s);
        if (GL20.glGetShaderi(s, GL20.GL_COMPILE_STATUS) == 0) {
            throw new IllegalStateException(GL20.glGetShaderInfoLog(s));
        }
        return s;
    }

    private static void initGl() {
        int vs = compile(GL20.GL_VERTEX_SHADER, VS);
        int fs = compile(GL20.GL_FRAGMENT_SHADER, FS);
        program = GL20.glCreateProgram();
        GL20.glAttachShader(program, vs);
        GL20.glAttachShader(program, fs);
        GL20.glBindAttribLocation(program, 0, "pos");
        GL20.glLinkProgram(program);
        if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == 0) {
            throw new IllegalStateException(GL20.glGetProgramInfoLog(program));
        }
        GL20.glDeleteShader(vs);
        GL20.glDeleteShader(fs);
        uTex = GL20.glGetUniformLocation(program, "tex");
        uAlpha = GL20.glGetUniformLocation(program, "alpha");

        vao = GL30.glGenVertexArrays();
        vbo = GL15.glGenBuffers();
        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, new float[]{-1, -1, 1, -1, -1, 1, 1, 1}, GL15.GL_STATIC_DRAW);
        GL20.glEnableVertexAttribArray(0);
        GL20.glVertexAttribPointer(0, 2, GL11.GL_FLOAT, false, 0, 0L);
        GL30.glBindVertexArray(0);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        BufferRenderer.reset();
        glReady = true;
    }

    private static void blend(Framebuffer fb, float alpha) {
        boolean blendOn = GL11.glIsEnabled(GL11.GL_BLEND);
        boolean depthOn = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);

        fb.beginWrite(false);
        // Minecraft's own state wrappers: its cache stays in sync with what OpenGL really has
        GlStateManager._disableDepthTest();
        GlStateManager._enableBlend();
        GlStateManager._blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);

        // our own texture unit: Minecraft's texture cache is never touched
        GL13.glActiveTexture(GL13.GL_TEXTURE0 + UNIT);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, history.getColorAttachment());
        GL20.glUseProgram(program);
        GL20.glUniform1i(uTex, UNIT);
        GL20.glUniform1f(uAlpha, alpha);
        GL30.glBindVertexArray(vao);
        GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);

        // put everything back
        GL30.glBindVertexArray(0);
        GL20.glUseProgram(0);
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        BufferRenderer.reset(); // forget the cached vertex buffer so Minecraft re-binds its own
        if (!blendOn) GlStateManager._disableBlend();
        if (depthOn) GlStateManager._enableDepthTest();
    }
}
