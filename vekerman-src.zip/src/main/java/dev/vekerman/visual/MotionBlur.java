package dev.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

/**
 * Frame blending: the previous frame is mixed over the current one. Plain OpenGL with its own tiny shader,
 * the GL state is saved and restored around the draw. Any error switches the effect off for the session.
 */
public class MotionBlur {
    private static SimpleFramebuffer history;
    private static boolean fresh = true;
    private static boolean failed = false;
    private static boolean glReady = false;
    private static int program, vao, vbo, uTex;

    private static final String VS = "#version 150\nin vec2 pos;\nout vec2 uv;\nvoid main(){ uv = pos * 0.5 + 0.5; gl_Position = vec4(pos, 0.0, 1.0); }\n";
    private static final String FS = "#version 150\nuniform sampler2D tex;\nin vec2 uv;\nout vec4 frag;\nvoid main(){ frag = vec4(texture(tex, uv).rgb, 1.0); }\n";

    public static void apply() {
        if (failed || !Config.on("motionblur")) {
            fresh = true;
            return;
        }
        try {
            doApply();
        } catch (Throwable t) {
            failed = true;
        }
    }

    private static void doApply() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Framebuffer fb = mc.getFramebuffer();
        int w = fb.textureWidth;
        int h = fb.textureHeight;
        if (history == null) {
            history = new SimpleFramebuffer(w, h, false);
            fresh = true;
        } else if (history.textureWidth != w || history.textureHeight != h) {
            history.resize(w, h);
            fresh = true;
        }
        if (!glReady) initGl();

        if (!fresh) blend(fb, (float) Config.num("motionblur", "strength"));

        // remember this frame
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, fb.fbo);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, history.fbo);
        GL30.glBlitFramebuffer(0, 0, w, h, 0, 0, w, h, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_NEAREST);
        fb.beginWrite(false);
        fresh = false;
    }

    private static int compile(int type, String src) {
        int s = GL20.glCreateShader(type);
        GL20.glShaderSource(s, src);
        GL20.glCompileShader(s);
        if (GL20.glGetShaderi(s, GL20.GL_COMPILE_STATUS) == 0) {
            throw new IllegalStateException(GL20.glGetShaderInfoLog(s));
        }
        return s;
    }

    private static void initGl() {
        int vs = compile(GL20.GL_VERTEX_SHADER, VS);
        int fs = compile(GL20.GL_FRAGMENT_SHADER, FS);
        program = GL20.glCreateProgram();
        GL20.glAttachShader(program, vs);
        GL20.glAttachShader(program, fs);
        GL20.glBindAttribLocation(program, 0, "pos");
        GL20.glLinkProgram(program);
        if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == 0) {
            throw new IllegalStateException(GL20.glGetProgramInfoLog(program));
        }
        GL20.glDeleteShader(vs);
        GL20.glDeleteShader(fs);
        uTex = GL20.glGetUniformLocation(program, "tex");

        int prevVao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        int prevBuf = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
        vao = GL30.glGenVertexArrays();
        vbo = GL15.glGenBuffers();
        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, new float[]{-1, -1, 1, -1, -1, 1, 1, 1}, GL15.GL_STATIC_DRAW);
        GL20.glEnableVertexAttribArray(0);
        GL20.glVertexAttribPointer(0, 2, GL11.GL_FLOAT, false, 0, 0L);
        GL30.glBindVertexArray(prevVao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, prevBuf);
        glReady = true;
    }

    private static void blend(Framebuffer fb, float strength) {
        int prevProg = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
        int prevVao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        int prevActive = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        int prevTex = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
        boolean blendOn = GL11.glIsEnabled(GL11.GL_BLEND);
        boolean depthOn = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        boolean cullOn = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        int sRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
        int dRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        int sA = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
        int dA = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        float[] bc = new float[4];
        GL11.glGetFloatv(GL14.GL_BLEND_COLOR, bc);

        fb.beginWrite(false);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_CULL_FACE);
        GL11.glEnable(GL11.GL_BLEND);
        GL14.glBlendColor(0f, 0f, 0f, strength);
        GL14.glBlendFuncSeparate(GL14.GL_CONSTANT_ALPHA, GL14.GL_ONE_MINUS_CONSTANT_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, history.getColorAttachment());
        GL20.glUseProgram(program);
        GL20.glUniform1i(uTex, 0);
        GL30.glBindVertexArray(vao);
        GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);

        GL30.glBindVertexArray(prevVao);
        GL20.glUseProgram(prevProg);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, prevTex);
        GL13.glActiveTexture(prevActive);
        GL14.glBlendColor(bc[0], bc[1], bc[2], bc[3]);
        GL14.glBlendFuncSeparate(sRgb, dRgb, sA, dA);
        if (!blendOn) GL11.glDisable(GL11.GL_BLEND);
        if (depthOn) GL11.glEnable(GL11.GL_DEPTH_TEST);
        if (cullOn) GL11.glEnable(GL11.GL_CULL_FACE);
    }
}
