package dev.vekerman.visual;

/** Flags set by the mixins the first time they run, so the rest of the mod knows which hooks really work. */
public class Hooks {
    public static volatile boolean fovHooked;
    public static volatile boolean mouseHooked;
    public static volatile boolean camHooked;
    public static volatile boolean cullHooked;
    public static volatile boolean blurHooked;
    public static volatile boolean armorHurt;
    public static volatile boolean armorMixinSeen;
    public static volatile double zoomFactor = 1.0;

    public static boolean lookReady() {
        return mouseHooked && camHooked;
    }
}
