package dev.vekerman.visual;

/** Camera rotation that is independent from the player while the Free Look key is held. */
public class FreeLook {
    public static volatile boolean active;
    public static volatile float yaw;
    public static volatile float pitch;

    public static void start(float y, float p) {
        yaw = y;
        pitch = p;
        active = true;
    }

    public static void stop() {
        active = false;
    }

    public static void turn(double dx, double dy) {
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) dy * 0.15f));
        yaw += (float) dx * 0.15f;
    }
}
