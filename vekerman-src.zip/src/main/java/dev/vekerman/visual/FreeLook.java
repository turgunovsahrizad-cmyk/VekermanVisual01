package dev.vekerman.visual;

import net.minecraft.entity.Entity;

/** Camera rotation that is independent from the player while Free Look is active. */
public class FreeLook {
    public static volatile boolean active;
    public static volatile float yaw;
    public static volatile float pitch;
    private static float lockYaw;
    private static float lockPitch;

    public static void start(float y, float p) {
        yaw = y;
        pitch = p;
        lockYaw = y;
        lockPitch = p;
        active = true;
    }

    public static void stop() {
        active = false;
    }

    /** used by the mouse mixin (if it is active): turns the camera only */
    public static void turn(double dx, double dy) {
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) dy * 0.15f));
        yaw += (float) dx * 0.15f;
    }

    /**
     * Works without any mouse hook: whatever the mouse turned on the player this frame is moved to the camera,
     * and the player is turned back to the saved direction.
     */
    public static void absorb(Entity player) {
        float dyaw = player.getYaw() - lockYaw;
        float dpitch = player.getPitch() - lockPitch;
        if (dyaw != 0f || dpitch != 0f) {
            yaw += dyaw;
            pitch = Math.max(-90f, Math.min(90f, pitch + dpitch));
            player.setYaw(lockYaw);
            player.setPitch(lockPitch);
        }
    }
}
