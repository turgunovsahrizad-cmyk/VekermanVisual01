package dev.vekerman.visual;

import java.util.ArrayList;
import java.util.List;

/** Static definition of every module, its tab, description and settings. */
public class Defs {
    public static final String[] TABS = {"Combat", "Movement", "Visual", "HUD", "Utilities", "Config"};

    public static class Setting {
        public final String id, label;
        public final char type; // S = slider, T = toggle, C = choice
        public final double min, max, step, def;
        public final String[] opts;

        Setting(String id, String label, char type, double min, double max, double step, double def, String[] opts) {
            this.id = id;
            this.label = label;
            this.type = type;
            this.min = min;
            this.max = max;
            this.step = step;
            this.def = def;
            this.opts = opts;
        }
    }

    public static class Module {
        public final String tab, id, name, desc;
        public final boolean impl, hud, defOn;
        public final int defKey, dx, dy;
        public final List<Setting> settings = new ArrayList<>();

        Module(String tab, String id, String name, String desc, boolean impl, boolean hud,
               boolean defOn, int defKey, int dx, int dy) {
            this.tab = tab;
            this.id = id;
            this.name = name;
            this.desc = desc;
            this.impl = impl;
            this.hud = hud;
            this.defOn = defOn;
            this.defKey = defKey;
            this.dx = dx;
            this.dy = dy;
        }

        public Setting setting(String sid) {
            for (Setting s : settings) if (s.id.equals(sid)) return s;
            return null;
        }
    }

    public static final List<Module> ALL = new ArrayList<>();

    static Setting slider(String id, String label, double min, double max, double step, double def) {
        return new Setting(id, label, 'S', min, max, step, def, null);
    }

    static Setting toggle(String id, String label, boolean def) {
        return new Setting(id, label, 'T', 0, 1, 1, def ? 1 : 0, null);
    }

    static Setting choice(String id, String label, String... opts) {
        return new Setting(id, label, 'C', 0, opts.length - 1, 1, 0, opts);
    }

    private static void add(String tab, String id, String name, String desc, boolean impl, boolean hud,
                            boolean defOn, int defKey, int dx, int dy, Setting... s) {
        Module m = new Module(tab, id, name, desc, impl, hud, defOn, defKey, dx, dy);
        if (hud) m.settings.add(slider("scale", "Size", 0.5, 2.0, 0.05, 1.0));
        for (Setting x : s) m.settings.add(x);
        ALL.add(m);
    }

    public static Module find(String id) {
        for (Module m : ALL) if (m.id.equals(id)) return m;
        return null;
    }

    static {
        // GLFW key codes: C = 67
        // ---- Combat ----
        add("Combat", "hitcolor", "HitColor", "Change hit entity highlight color", true, false, false, -1, 0, 0,
                choice("color", "Color", "Red", "Blue", "Green", "Purple", "Yellow", "White", "Cyan", "Orange"),
                slider("opacity", "Opacity", 0.3, 1.0, 0.05, 0.7));
        add("Combat", "damageindicator", "Damage Indicator", "Show damage numbers on hit", true, false, false, -1, 0, 0,
                slider("size", "Number size", 0.6, 2.0, 0.1, 1.0),
                slider("time", "Duration (s)", 0.5, 3.0, 0.1, 1.2));

        // ---- Movement ----
        add("Movement", "autosprint", "AutoSprint", "Automatically sprint while moving", true, false, false, -1, 0, 0);
        add("Movement", "freelook", "Free Look", "Look around without turning player", true, false, true, 342, 0, 0);

        // ---- Visual ----
        add("Visual", "zoom", "Zoom", "Smooth camera zoom on hold", true, false, true, 67, 0, 0,
                slider("strength", "Zoom strength", 1.2, 10.0, 0.1, 3.0),
                slider("smooth", "Smoothness", 1, 20, 1, 8),
                slider("scroll", "Scroll step", 0.05, 0.5, 0.05, 0.2));
        add("Visual", "fullbright", "Fullbright", "Max brightness, full lighting", true, false, false, -1, 0, 0);
        add("Visual", "nametag", "Name Tag", "Always show player name tags", true, false, false, -1, 0, 0,
                slider("dist", "Max distance", 16, 128, 8, 64),
                toggle("health", "Show health", true));
        add("Visual", "motionblur", "Motion Blur", "Adds motion blur effect to view", true, false, false, -1, 0, 0,
                slider("strength", "Strength", 0.1, 0.9, 0.05, 0.5));
        add("Visual", "waypoints", "Waypoints", "Create and view world waypoints", true, false, true, -1, 0, 0,
                toggle("dist", "Show distance", true));

        // ---- HUD ----
        add("HUD", "fps", "FPS", "Show FPS counter", true, true, true, -1, 6, 6);
        add("HUD", "cps", "CPS", "Show CPS counter", true, true, true, -1, 6, 24);
        add("HUD", "keystrokes", "Keystrokes", "Show pressed keys", true, true, true, -1, 6, 62);
        add("HUD", "coords", "Coordinates", "Show XYZ coordinates", true, true, false, -1, 6, 42);
        add("HUD", "armorhud", "Armor HUD", "Show armor with durability %", true, true, false, -1, 400, 6,
                choice("layout", "Layout", "Vertical", "Horizontal"));
        add("HUD", "potionhud", "Potion HUD", "Show active effects with time", true, true, true, -1, 400, 70,
                choice("layout", "Layout", "Vertical", "Horizontal"),
                slider("alertsize", "Alert icon size", 8, 40, 2, 20),
                toggle("sound", "Alert sound", true),
                slider("volume", "Alert volume", 0, 1, 0.05, 0.4));
        add("HUD", "ping", "Ping", "Show ping", true, true, false, -1, 60, 6);

        // ---- Utilities ----
        add("Utilities", "togglesprint", "Toggle Sprint", "Hold or toggle sprint", true, false, false, -1, 0, 0,
                choice("mode", "Mode", "Toggle", "Hold"));
        add("Utilities", "fpsboost", "FPS Boost", "Optimize rendering for more FPS", true, false, true, -1, 0, 0);
        add("Utilities", "entityculling", "Entity Culling", "Don't render entities behind walls", true, false, false, -1, 0, 0,
                slider("mindist", "Min distance", 4, 32, 1, 8));
    }
}
