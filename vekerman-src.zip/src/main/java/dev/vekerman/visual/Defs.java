package dev.vekerman.visual;

import java.util.ArrayList;
import java.util.List;

/** Static definition of every module, its tab, description and settings. */
public class Defs {
    public static final String[] TABS = {"Combat", "Movement", "HUD", "Utilities", "Config"};

    public static class Setting {
        public final String id, label;
        public final char type; // S = slider, T = toggle, C = choice
        public final double min, max, step, def;
        public final String[] opts;

        Setting(String id, String label, char type, double min, double max, double step, double def, String[] opts) {
            this.id = id;
            this.label = label;
            this.type = type;
            this.min = min;
            this.max = max;
            this.step = step;
            this.def = def;
            this.opts = opts;
        }
    }

    public static class Module {
        public final String tab, id, name, desc;
        public final boolean impl, hud, defOn;
        public final int defKey, dx, dy;
        public final List<Setting> settings = new ArrayList<>();

        Module(String tab, String id, String name, String desc, boolean impl, boolean hud,
               boolean defOn, int defKey, int dx, int dy) {
            this.tab = tab;
            this.id = id;
            this.name = name;
            this.desc = desc;
            this.impl = impl;
            this.hud = hud;
            this.defOn = defOn;
            this.defKey = defKey;
            this.dx = dx;
            this.dy = dy;
        }

        public Setting setting(String sid) {
            for (Setting s : settings) if (s.id.equals(sid)) return s;
            return null;
        }
    }

    public static final List<Module> ALL = new ArrayList<>();

    static Setting slider(String id, String label, double min, double max, double step, double def) {
        return new Setting(id, label, 'S', min, max, step, def, null);
    }

    static Setting toggle(String id, String label, boolean def) {
        return new Setting(id, label, 'T', 0, 1, 1, def ? 1 : 0, null);
    }

    static Setting choice(String id, String label, String... opts) {
        return new Setting(id, label, 'C', 0, opts.length - 1, 1, 0, opts);
    }

    private static void add(String tab, String id, String name, String desc, boolean impl, boolean hud,
                            boolean defOn, int defKey, int dx, int dy, Setting... s) {
        Module m = new Module(tab, id, name, desc, impl, hud, defOn, defKey, dx, dy);
        if (hud && !id.equals("armorwarn")) m.settings.add(slider("scale", "Size", 0.5, 2.0, 0.05, 1.0));
        for (Setting x : s) m.settings.add(x);
        ALL.add(m);
    }

    public static Module find(String id) {
        for (Module m : ALL) if (m.id.equals(id)) return m;
        return null;
    }

    static {
        // ---- Combat ----
        add("Combat", "swap", "Swap", "Inventory swap macro: E - F - E", true, false, false, -1, 0, 0,
                slider("delay1", "Delay 1 (E -> F) ms", 30, 150, 5, 70),
                slider("delay2", "Delay 2 (F -> E) ms", 30, 150, 5, 70),
                toggle("sp", "Singleplayer only", false));
        add("Combat", "pvpcount", "PvP Counter", "Totems, gapples, pearls, potions you carry", true, true, true, -1, 6, 140,
                toggle("totem", "Totems", true),
                toggle("gapple", "Golden apples", true),
                toggle("pearl", "Ender pearls", true),
                toggle("potion", "Potions", true));

        // ---- Movement ----
        add("Movement", "autosprint", "AutoSprint", "Automatically sprint while moving", true, false, false, -1, 0, 0);

        // ---- HUD ----
        add("HUD", "fps", "FPS", "Show FPS counter", true, true, true, -1, 6, 6);
        add("HUD", "cps", "CPS", "Show CPS counter", true, true, true, -1, 6, 24);
        add("HUD", "keystrokes", "Keystrokes", "Show pressed keys", true, true, true, -1, 6, 62);
        add("HUD", "coords", "Coordinates", "Show XYZ coordinates", true, true, false, -1, 6, 42);
        add("HUD", "armorhud", "Armor HUD", "Show armor with durability %", true, true, false, -1, 400, 6,
                choice("layout", "Layout", "Vertical", "Horizontal"));
        add("HUD", "potionhud", "Potion HUD", "Show active effects with time", true, true, true, -1, 400, 70,
                choice("layout", "Layout", "Vertical", "Horizontal"));
        add("HUD", "ping", "Ping", "Show ping", true, true, false, -1, 60, 6);
        add("HUD", "armorwarn", "Armor Warning", "Warn when armor durability is low", true, true, false, -1, -1, -1,
                slider("threshold", "Threshold %", 5, 50, 1, 15),
                choice("mode", "Show", "Most broken", "All broken"),
                slider("isize", "Icon size", 8, 40, 1, 16),
                toggle("sound", "Warning sound", true));

        // ---- Utilities ----
        add("Utilities", "fpsboost", "FPS Boost", "Optimize rendering for more FPS", true, false, true, -1, 0, 0);
    }
}
