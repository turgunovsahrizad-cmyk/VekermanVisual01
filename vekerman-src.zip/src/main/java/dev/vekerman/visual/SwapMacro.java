package dev.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.util.InputUtil;

/** Swap: E (open inventory) - delay 1 - F (swap hands key over the hovered slot) - delay 2 - E (close). Works everywhere unless "Singleplayer only" is on. */
public class SwapMacro {
    private static int stage = 0;
    private static long due = 0;

    public static boolean running() {
        return stage != 0;
    }

    public static void trigger(MinecraftClient mc) {
        if (stage != 0 || mc.player == null || mc.currentScreen != null) return;
        if (Config.flag("swap", "sp") && !mc.isInSingleplayer()) {
            Modules.message(mc, "Swap: singleplayer only is turned on");
            return;
        }
        mc.setScreen(new InventoryScreen(mc.player)); // E
        stage = 1;
        due = System.currentTimeMillis() + (long) Config.num("swap", "delay1");
    }

    /** called every frame */
    public static void frame(MinecraftClient mc) {
        if (stage == 0) return;
        if (mc.player == null) {
            stage = 0;
            return;
        }
        long now = System.currentTimeMillis();
        if (now < due) return;
        if (stage == 1) { // F
            Screen s = mc.currentScreen;
            if (s instanceof HandledScreen<?>) {
                try {
                    InputUtil.Key k = InputUtil.fromTranslationKey(mc.options.swapHandsKey.getBoundKeyTranslationKey());
                    if (k.getCategory() == InputUtil.Type.KEYSYM) s.keyPressed(k.getCode(), 0, 0);
                } catch (Exception e) {
                    // ignore
                }
            }
            stage = 2;
            due = now + (long) Config.num("swap", "delay2");
        } else { // E: close the inventory
            if (mc.currentScreen instanceof HandledScreen<?>) mc.player.closeHandledScreen();
            stage = 0;
        }
    }
}
