package dev.vekerman.visual;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Self-healing for mixins. Plain Java only (it runs before the game is loaded).
 *
 * A "launch.lock" file is written when the game starts and removed once the title screen is reached.
 * If the lock is still there at the next start, the previous start hung or crashed, so the suspect mixin
 * group is blocked and the game starts without it.
 */
public final class MixinState {
    public static final String[] GROUPS = {"zoom", "cull", "look", "blur"};

    private static final Set<String> verified = new LinkedHashSet<>();
    private static final Set<String> blocked = new LinkedHashSet<>();
    private static final Set<String> off = new LinkedHashSet<>();
    private static final List<String> queue = new ArrayList<>();
    private static final Set<String> active = new LinkedHashSet<>();
    private static String mode = "all"; // all | bisect | stable
    private static boolean loaded = false;

    private MixinState() {
    }

    private static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("VekermanVisual");
    }

    public static String groupOf(String mixinClass) {
        String n = mixinClass.substring(mixinClass.lastIndexOf('.') + 1);
        switch (n) {
            case "GameRendererZoomMixin":
                return "zoom";
            case "CameraMixin":
            case "MouseMixin":
                return "look";
            case "GameRendererBlurMixin":
                return "blur";
            case "EntityRenderDispatcherMixin":
                return "cull";
            default:
                return null;
        }
    }

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        try {
            Files.createDirectories(dir());
            readState();

            Path lock = dir().resolve("launch.lock");
            if (Files.exists(lock)) {
                // the previous start never reached the title screen
                Set<String> trial = parse(read(lock));
                trial.removeAll(verified);
                if (trial.size() == 1) {
                    blocked.addAll(trial);
                    queue.removeAll(trial);
                } else if (trial.size() > 1) {
                    mode = "bisect";
                    queue.clear();
                    for (String g : GROUPS) if (!verified.contains(g) && !blocked.contains(g)) queue.add(g);
                }
                Files.deleteIfExists(lock);
            }

            active.clear();
            if (mode.equals("all")) {
                for (String g : GROUPS) if (!off.contains(g) && !blocked.contains(g)) active.add(g);
            } else {
                for (String g : verified) if (!off.contains(g) && !blocked.contains(g)) active.add(g);
                if (mode.equals("bisect")) {
                    while (!queue.isEmpty()) {
                        String t = queue.remove(0);
                        if (off.contains(t) || blocked.contains(t) || verified.contains(t)) continue;
                        active.add(t);
                        break;
                    }
                }
            }
            write(lock, String.join(",", active));
            writeState();
        } catch (Throwable t) {
            active.clear(); // anything wrong: start with no mixins at all
        }
    }

    /** called once the title screen is reached */
    public static synchronized void markSuccess() {
        try {
            Files.deleteIfExists(dir().resolve("launch.lock"));
            verified.addAll(active);
            if (mode.equals("all")) {
                mode = "stable";
            } else if (mode.equals("bisect")) {
                boolean pending = false;
                for (String g : queue) if (!verified.contains(g) && !blocked.contains(g) && !off.contains(g)) pending = true;
                if (!pending) mode = "stable";
            }
            writeState();
        } catch (Throwable t) {
            // ignore
        }
    }

    public static synchronized boolean isActive(String g) {
        return active.contains(g);
    }

    /** ACTIVE, TESTING (active but not proven yet), QUEUED, BLOCKED or OFF */
    public static synchronized String status(String g) {
        if (blocked.contains(g)) return "BLOCKED";
        if (off.contains(g)) return "OFF";
        if (active.contains(g)) return verified.contains(g) ? "ACTIVE" : "TESTING";
        return "QUEUED";
    }

    public static synchronized void toggleOff(String g) {
        if (!off.remove(g)) off.add(g);
        if (!off.contains(g) && !verified.contains(g) && !queue.contains(g)) queue.add(g);
        writeState();
    }

    public static synchronized void retry(String g) {
        blocked.remove(g);
        off.remove(g);
        verified.remove(g);
        if (!queue.contains(g)) queue.add(0, g);
        mode = "bisect";
        writeState();
    }

    // ---------------------------------------------------------------- files

    private static Set<String> parse(String s) {
        Set<String> out = new LinkedHashSet<>();
        if (s == null) return out;
        for (String p : s.split(",")) {
            String t = p.trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    private static String read(Path p) throws Exception {
        return new String(Files.readAllBytes(p), StandardCharsets.UTF_8).trim();
    }

    private static void write(Path p, String s) throws Exception {
        Files.write(p, s.getBytes(StandardCharsets.UTF_8));
    }

    private static void readState() {
        try {
            Path p = dir().resolve("mixins.state");
            if (!Files.exists(p)) return;
            for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
                int i = line.indexOf('=');
                if (i < 0) continue;
                String k = line.substring(0, i).trim();
                String v = line.substring(i + 1).trim();
                switch (k) {
                    case "mode":
                        mode = v.isEmpty() ? "all" : v;
                        break;
                    case "verified":
                        verified.addAll(parse(v));
                        break;
                    case "blocked":
                        blocked.addAll(parse(v));
                        break;
                    case "off":
                        off.addAll(parse(v));
                        break;
                    case "queue":
                        queue.addAll(parse(v));
                        break;
                    default:
                        break;
                }
            }
        } catch (Throwable t) {
            // corrupt state file: use defaults
        }
    }

    private static void writeState() {
        try {
            String s = "mode=" + mode + "\n"
                    + "verified=" + String.join(",", verified) + "\n"
                    + "blocked=" + String.join(",", blocked) + "\n"
                    + "off=" + String.join(",", off) + "\n"
                    + "queue=" + String.join(",", queue) + "\n";
            write(dir().resolve("mixins.state"), s);
        } catch (Throwable t) {
            // ignore
        }
    }
}
