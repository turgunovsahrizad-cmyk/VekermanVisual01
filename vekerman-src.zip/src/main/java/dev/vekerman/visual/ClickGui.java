package dev.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;
import java.util.function.Supplier;

public class ClickGui extends Screen {
    private static final int PURPLE = 0xFF8B5CF6;
    private static final int PURPLE_LIGHT = 0xFFA78BFA;
    private static final int BG = 0xFF0F0F12;
    private static final int CARD = 0xFF1A1A1E;
    private static final int CARD_BORDER = 0xFF26262C;
    private static final int FIELD = 0xFF141418;
    private static final int TEXT = 0xFFF2F2F7;
    private static final int DIM = 0xFF9A9AA6;
    private static final int DANGER = 0xFFC94A4A;
    private static final int GOOD = 0xFF2FBF71;
    private static final int RH = 23;

    private static class Ref {
        final Supplier<String> getter;
        final Consumer<String> setter;

        Ref(Supplier<String> getter, Consumer<String> setter) {
            this.getter = getter;
            this.setter = setter;
        }
    }

    private static class Hit {
        final int x, y, w, h;
        final Runnable left, right;
        final DoubleConsumer drag;
        final int trackX, trackW;

        Hit(int x, int y, int w, int h, Runnable left, Runnable right, DoubleConsumer drag, int trackX, int trackW) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.left = left;
            this.right = right;
            this.drag = drag;
            this.trackX = trackX;
            this.trackW = trackW;
        }
    }

    private int tab = 2; // Visual, like on the reference screenshot
    private int cfgPage = 0;
    private String settingsFor = null;
    private String search = "";
    private boolean moveMode = false;

    private int scroll = 0;
    private int contentH = 0;
    private final List<Hit> hits = new ArrayList<>();
    private int px, py, pw, ph;
    private int areaX, areaY, areaW, areaH;
    private int clipY1 = Integer.MIN_VALUE;
    private int clipY2 = Integer.MAX_VALUE;

    private IntConsumer listening = null;
    private Object listenToken = null;
    private Ref editing = null;
    private Object editToken = null;
    private final StringBuilder buf = new StringBuilder();

    private String dragId = null;
    private int dragOx, dragOy;
    private Hit activeDrag = null;
    private boolean scrolling = false;
    private boolean dirty = false;

    private boolean addingConfig = false;
    private String newName = "";
    private boolean confirmPending = false;
    private boolean confirmArmed = false;

    private TextRenderer tr;

    public ClickGui() {
        super(Text.literal("VekermanVisual"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        Config.saveCurrent();
        Config.saveWaypoints();
    }

    // ================================================================== render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        tr = MinecraftClient.getInstance().textRenderer;
        hits.clear();
        clipY1 = Integer.MIN_VALUE;
        clipY2 = Integer.MAX_VALUE;

        if (moveMode) {
            renderMove(ctx, mx, my);
            return;
        }

        ctx.fill(0, 0, width, height, 0x88000000);
        pw = Math.min(width - 12, 430);
        ph = Math.min(height - 10, 238);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        Draw.card(ctx, px, py, pw, ph, 9, 0xFF22222A, BG);

        // header: logo + title (left), search (right)
        Draw.logo(ctx, px + 10, py + 9, PURPLE);
        ctx.drawText(tr, Text.literal("VekermanVisual").formatted(Formatting.BOLD), px + 26, py + 11, 0xFFFFFFFF, false);

        int sw = Math.min(130, pw / 3);
        int sx = px + pw - 10 - sw;
        Draw.card(ctx, sx, py + 8, sw, 18, 6, CARD_BORDER, 0xFF17171B);
        boolean searchActive = editing != null && editToken == "search";
        String st = searchActive ? buf.toString() : search;
        if (st.isEmpty() && !searchActive) {
            ctx.drawText(tr, "Search modules...", sx + 8, py + 13, 0xFF6C6C78, false);
        } else {
            String shown = tr.trimToWidth(st, sw - 16, true);
            if (searchActive && (System.currentTimeMillis() / 500) % 2 == 0) shown += "_";
            ctx.drawText(tr, shown, sx + 8, py + 13, TEXT, false);
        }
        addHit(sx, py + 8, sw, 18, () -> startEdit(new Ref(() -> search, s -> {
            search = s;
            scroll = 0;
        }), "search"), null, null, 0, 0);

        if (tab == 3 && settingsFor == null && search.isEmpty()) {
            button(ctx, sx - 70, py + 8, 64, 18, "Move HUD", 0xFF26262C, TEXT, mx, my, () -> moveMode = true, null);
        }

        areaX = px + 10;
        areaY = py + 34;
        areaW = pw - 20;
        areaH = ph - 34 - 32;

        if (settingsFor != null) renderSettings(ctx, mx, my);
        else if (tab == 5 && search.isEmpty()) renderConfig(ctx, mx, my);
        else renderCards(ctx, mx, my);

        renderTabs(ctx, mx, my);
    }

    private void renderTabs(DrawContext ctx, int mx, int my) {
        int n = Defs.TABS.length;
        int[] w = new int[n];
        int total = 0;
        int gap = 4;
        for (int i = 0; i < n; i++) {
            w[i] = 7 + 4 + tr.getWidth(Defs.TABS[i]) + 14;
            total += w[i];
        }
        total += gap * (n - 1);
        int x = px + (pw - total) / 2;
        int y = py + ph - 26;
        for (int i = 0; i < n; i++) {
            final int idx = i;
            boolean active = (tab == i && search.isEmpty());
            Draw.card(ctx, x, y, w[i], 18, 7, active ? PURPLE : 0xFF2A2A31, active ? PURPLE : CARD);
            Draw.tabIcon(ctx, i, x + 7, y + 5, active ? 0xFFFFFFFF : DIM);
            ctx.drawText(tr, Defs.TABS[i], x + 18, y + 5, active ? 0xFFFFFFFF : 0xFFC9C9D3, false);
            addHit(x, y, w[i], 18, () -> {
                tab = idx;
                settingsFor = null;
                search = "";
                scroll = 0;
                cfgPage = 0;
            }, null, null, 0, 0);
            x += w[i] + gap;
        }
    }

    // ------------------------------------------------------------------ module cards

    private void renderCards(DrawContext ctx, int mx, int my) {
        List<Defs.Module> list = new ArrayList<>();
        String q = search.toLowerCase(Locale.ROOT);
        for (Defs.Module m : Defs.ALL) {
            if (!q.isEmpty()) {
                if (m.name.toLowerCase(Locale.ROOT).contains(q)) list.add(m);
            } else if (m.tab.equals(Defs.TABS[tab])) {
                list.add(m);
            }
        }
        int cardW = (areaW - 6) / 2;
        int cardH = 30;
        int gap = 6;
        int rows = (list.size() + 1) / 2;
        contentH = Math.max(0, rows * (cardH + gap) - gap);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentH - areaH)));

        beginClip(ctx, areaY);
        for (int i = 0; i < list.size(); i++) {
            Defs.Module m = list.get(i);
            int x = areaX + (i % 2) * (cardW + 6);
            int y = areaY + (i / 2) * (cardH + gap) - scroll;
            if (y + cardH < areaY || y > areaY + areaH) continue;

            Draw.card(ctx, x, y, cardW, cardH, 6, CARD_BORDER, CARD);
            ctx.drawText(tr, Text.literal(tr.trimToWidth(m.name, cardW - 52)).formatted(Formatting.BOLD),
                    x + 9, y + 5, 0xFFFFFFFF, false);
            ctx.drawText(tr, tr.trimToWidth(m.desc, cardW - 54), x + 9, y + 17, DIM, false);

            if (m.impl) {
                final Config.Mod cm = Config.mod(m.id);
                final String id = m.id;
                Draw.gear(ctx, x + cardW - 45, y + 10, 0xFF7C7C88);
                addHit(x + cardW - 49, y + 5, 17, 20, () -> {
                    settingsFor = id;
                    scroll = 0;
                }, null, null, 0, 0);
                Draw.toggle(ctx, x + cardW - 30, y + 10, cm.enabled, PURPLE);
                addHit(x + cardW - 33, y + 6, 28, 18, () -> {
                    cm.enabled = !cm.enabled;
                    Config.saveCurrent();
                }, null, null, 0, 0);
            } else {
                Draw.rrect(ctx, x + cardW - 38, y + 10, 30, 11, 5, 0xFF2A2A31);
                ctx.drawText(tr, "SOON", x + cardW - 38 + (30 - tr.getWidth("SOON")) / 2, y + 12, 0xFF8A8A96, false);
            }
        }
        endClip(ctx);
    }

    // ------------------------------------------------------------------ settings of one module

    private void renderSettings(DrawContext ctx, int mx, int my) {
        final Defs.Module m = Defs.find(settingsFor);
        if (m == null) {
            settingsFor = null;
            return;
        }
        button(ctx, areaX, areaY, 48, 16, "< Back", 0xFF26262C, TEXT, mx, my, () -> {
            settingsFor = null;
            scroll = 0;
        }, null);
        ctx.drawText(tr, Text.literal(m.name).formatted(Formatting.BOLD), areaX + 56, areaY + 4, 0xFFFFFFFF, false);
        ctx.drawText(tr, m.desc, areaX + 56 + tr.getWidth(m.name) + 10, areaY + 4, DIM, false);

        int top = areaY + 22;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentH - (areaY + areaH - top))));
        beginClip(ctx, top);
        int y = top - scroll;
        int start = y;

        final Config.Mod cm = Config.mod(m.id);
        keyRow(ctx, y, "Keybind", m.id, cm.key, v -> {
            cm.key = v;
            Config.saveCurrent();
        }, mx, my);
        y += RH;

        for (final Defs.Setting s : m.settings) {
            if (s.type == 'S') {
                sliderRow(ctx, y, s.label, s.min, s.max, s.step, Config.num(m.id, s.id), v -> {
                    cm.n.put(s.id, v);
                    dirty = true;
                }, mx, my);
            } else if (s.type == 'T') {
                boolean val = Config.flag(m.id, s.id);
                toggleRow(ctx, y, s.label, val, () -> {
                    cm.n.put(s.id, val ? 0.0 : 1.0);
                    Config.saveCurrent();
                }, mx, my);
            } else {
                final String curv = Config.str(m.id, s.id);
                choiceRow(ctx, y, s.label, curv, () -> {
                    int idx = 0;
                    for (int i = 0; i < s.opts.length; i++) if (s.opts[i].equals(curv)) idx = i;
                    cm.s.put(s.id, s.opts[(idx + 1) % s.opts.length]);
                    Config.saveCurrent();
                }, mx, my);
            }
            y += RH;
        }

        if (m.hud) {
            buttonRow(ctx, y, "Reset position", () -> {
                cm.x = m.dx;
                cm.y = m.dy;
                Config.saveCurrent();
            }, mx, my);
            y += RH;
        }

        if (m.id.equals("waypoints")) {
            buttonRow(ctx, y, "+ Add waypoint at my position", () -> Modules.addWaypoint(MinecraftClient.getInstance()), mx, my);
            y += RH;
            MinecraftClient mc = MinecraftClient.getInstance();
            String dim = mc.world != null ? Modules.dimension(mc) : "";
            for (int i = 0; i < Config.waypoints.size(); i++) {
                final Config.Waypoint w = Config.waypoints.get(i);
                if (visible(y)) {
                    row(ctx, y);
                    int rx = areaX + areaW - 6;
                    final Config.Waypoint wf = w;
                    button(ctx, rx - 14, y + 3, 14, 14, "x", DANGER, 0xFFFFFFFF, mx, my, () -> {
                        Config.waypoints.remove(wf);
                        Config.saveWaypoints();
                    }, null);
                    Draw.toggle(ctx, rx - 14 - 28, y + 5, w.visible, PURPLE);
                    addHit(rx - 14 - 31, y + 2, 28, 16, () -> {
                        wf.visible = !wf.visible;
                        Config.saveWaypoints();
                    }, null, null, 0, 0);
                    String dist = "-";
                    if (mc.player != null && w.dim.equals(dim)) {
                        double dx = w.x - mc.player.getX();
                        double dy = w.y - mc.player.getY();
                        double dz = w.z - mc.player.getZ();
                        dist = (int) Math.sqrt(dx * dx + dy * dy + dz * dz) + "m";
                    }
                    int dw = 38;
                    int dxp = rx - 14 - 34 - dw;
                    ctx.drawText(tr, dist, dxp, y + 6, DIM, false);
                    int swx = areaX + 6;
                    Draw.rrect(ctx, swx, y + 4, 12, 12, 3, w.color);
                    addHit(swx, y + 4, 12, 12, () -> {
                        int idx = 0;
                        for (int k = 0; k < Modules.PALETTE.length; k++) if (Modules.PALETTE[k] == wf.color) idx = k;
                        wf.color = Modules.PALETTE[(idx + 1) % Modules.PALETTE.length];
                        Config.saveWaypoints();
                    }, null, null, 0, 0);
                    textField(ctx, swx + 16, y + 2, dxp - 4 - (swx + 16), 16,
                            new Ref(() -> wf.name, s -> wf.name = s), wf);
                }
                y += RH;
            }
        }

        contentH = y - start;
        endClip(ctx);
    }

    // ------------------------------------------------------------------ Config tab

    private void renderConfig(DrawContext ctx, int mx, int my) {
        String[] pages = {"Profiles", "Commands", "Optimization", "Keybinds", "Style", "Mixins"};
        int x = areaX;
        for (int i = 0; i < pages.length; i++) {
            final int idx = i;
            int w = tr.getWidth(pages[i]) + 16;
            Draw.card(ctx, x, areaY, w, 16, 6, cfgPage == i ? PURPLE : 0xFF2A2A31, cfgPage == i ? PURPLE : CARD);
            ctx.drawText(tr, pages[i], x + 8, areaY + 4, cfgPage == i ? 0xFFFFFFFF : 0xFFC9C9D3, false);
            addHit(x, areaY, w, 16, () -> {
                cfgPage = idx;
                scroll = 0;
                addingConfig = false;
            }, null, null, 0, 0);
            x += w + 4;
        }

        int top = areaY + 22;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentH - (areaY + areaH - top))));
        beginClip(ctx, top);
        int y = top - scroll;
        int start = y;

        if (cfgPage == 0) y = pageProfiles(ctx, y, mx, my);
        else if (cfgPage == 1) y = pageCommands(ctx, y, mx, my);
        else if (cfgPage == 2) y = pageOptimization(ctx, y, mx, my);
        else if (cfgPage == 3) y = pageKeybinds(ctx, y, mx, my);
        else if (cfgPage == 4) y = pageStyle(ctx, y, mx, my);
        else y = pageMixins(ctx, y, mx, my);

        contentH = y - start;
        endClip(ctx);
    }

    private int pageProfiles(DrawContext ctx, int y, int mx, int my) {
        if (visible(y)) {
            button(ctx, areaX, y, 100, 18, "+ Add Config", PURPLE, 0xFFFFFFFF, mx, my, () -> {
                addingConfig = true;
                newName = "";
            }, null);
            button(ctx, areaX + 106, y, 86, 18, confirmPending ? "Confirm reset?" : "Reset All",
                    confirmPending ? DANGER : 0xFF2A2A31, 0xFFFFFFFF, mx, my, () -> {
                        if (confirmArmed) {
                            Config.applySettings(Config.defaults());
                        } else {
                            confirmPending = true;
                        }
                    }, null);
        }
        y += 22;

        if (addingConfig) {
            if (visible(y)) {
                row(ctx, y);
                textField(ctx, areaX + 4, y + 2, areaW - 4 - 100, 16, new Ref(() -> newName, s -> newName = s), "newName");
                button(ctx, areaX + areaW - 94, y + 2, 44, 16, "Save", GOOD, 0xFFFFFFFF, mx, my, () -> {
                    if (Config.saveProfile(newName)) {
                        addingConfig = false;
                        newName = "";
                    }
                }, null);
                button(ctx, areaX + areaW - 48, y + 2, 44, 16, "Cancel", 0xFF3A3A44, 0xFFFFFFFF, mx, my,
                        () -> addingConfig = false, null);
            }
            y += RH;
        }

        List<String> names = Config.listProfiles();
        if (names.isEmpty()) {
            if (visible(y)) ctx.drawText(tr, "No saved configs yet. Press + Add Config.", areaX + 2, y + 4, DIM, false);
            y += 12;
        }
        for (final String n : names) {
            if (visible(y)) {
                row(ctx, y);
                ctx.drawText(tr, tr.trimToWidth(n, areaW - 160), areaX + 8, y + 6, TEXT, false);
                int rx = areaX + areaW - 4;
                button(ctx, rx - 44, y + 2, 44, 16, "Delete", DANGER, 0xFFFFFFFF, mx, my, () -> Config.deleteProfile(n), null);
                button(ctx, rx - 44 - 4 - 40, y + 2, 40, 16, "Save", 0xFF3A3A44, 0xFFFFFFFF, mx, my, () -> Config.saveProfile(n), null);
                button(ctx, rx - 44 - 4 - 40 - 4 - 40, y + 2, 40, 16, "Load", PURPLE, 0xFFFFFFFF, mx, my, () -> Config.loadProfile(n), null);
            }
            y += RH;
        }
        if (visible(y)) {
            ctx.drawText(tr, "Folder: VekermanVisual/configs/<name>.json", areaX + 2, y + 6, 0xFF6C6C78, false);
        }
        y += 18;
        return y;
    }

    private int pageCommands(DrawContext ctx, int y, int mx, int my) {
        if (visible(y)) {
            button(ctx, areaX, y, 110, 18, "+ Add command", PURPLE, 0xFFFFFFFF, mx, my, () -> {
                Config.cur.cmds.add(new Config.CmdBind());
                Config.saveCurrent();
            }, null);
            ctx.drawText(tr, "Bind any chat command to a key", areaX + 118, y + 5, DIM, false);
        }
        y += 22;
        if (Config.cur.cmds.isEmpty()) {
            if (visible(y)) ctx.drawText(tr, "Press + Add command, click the text, type /home, set a key.", areaX + 2, y + 4, DIM, false);
            y += 14;
        }
        for (final Config.CmdBind c : new java.util.ArrayList<>(Config.cur.cmds)) {
            if (visible(y)) {
                row(ctx, y);
                int tw = 28;
                int tx = areaX + 4;
                button(ctx, tx, y + 2, tw, 16, c.enabled ? "ON" : "OFF", c.enabled ? GOOD : 0xFF3A3A44, 0xFFFFFFFF, mx, my, () -> {
                    c.enabled = !c.enabled;
                    Config.saveCurrent();
                }, null);
                int xw = 14;
                int bx = areaX + areaW - 4 - xw;
                button(ctx, bx, y + 3, xw, 14, "x", DANGER, 0xFFFFFFFF, mx, my, () -> {
                    Config.cur.cmds.remove(c);
                    Config.saveCurrent();
                }, null);
                int kw = 66;
                int kx = bx - 3 - kw;
                boolean waiting = listenToken == c;
                button(ctx, kx, y + 2, kw, 16, waiting ? "press key..." : Modules.keyName(c.key), waiting ? PURPLE : FIELD,
                        waiting ? 0xFFFFFFFF : TEXT, mx, my, () -> {
                            listening = v -> c.key = v;
                            listenToken = c;
                        }, () -> {
                            c.key = -1;
                            Config.saveCurrent();
                        });
                int nx = tx + tw + 3;
                textField(ctx, nx, y + 2, kx - 3 - nx, 16, new Ref(() -> c.command, s -> c.command = s), c);
            }
            y += RH;
        }
        return y;
    }

    private int pageOptimization(DrawContext ctx, int y, int mx, int my) {
        String[][] opts = {
                {"dynamicFps", "Dynamic FPS (low FPS when in background)"},
                {"fastChunk", "Fast Chunk Loading"},
                {"particleOpt", "Particle Optimizer"},
                {"smoothFps", "Smooth FPS (stable cap, no vsync)"},
                {"memoryCleaner", "Memory Cleaner (only in menus)"}};
        for (final String[] o : opts) {
            final boolean val = Config.ob(o[0]);
            toggleRow(ctx, y, o[1], val, () -> {
                Config.cur.optb.put(o[0], !val);
                Config.saveCurrent();
            }, mx, my);
            y += RH;
            if (o[0].equals("particleOpt")) {
                sliderRow(ctx, y, "Particles %", 0, 100, 5, Config.optn("particleLevel"), v -> {
                    Config.cur.optn.put("particleLevel", v);
                    dirty = true;
                }, mx, my);
                y += RH;
            }
            if (o[0].equals("smoothFps")) {
                sliderRow(ctx, y, "FPS cap", 30, 240, 10, Config.optn("fpsCap"), v -> {
                    Config.cur.optn.put("fpsCap", v);
                    dirty = true;
                }, mx, my);
                y += RH;
            }
        }
        if (visible(y)) ctx.drawText(tr, "FPS Boost is in the Utilities tab (on by default).", areaX + 2, y + 4, 0xFF6C6C78, false);
        y += 14;
        if (visible(y)) {
            row(ctx, y);
            String t = String.format(Locale.ROOT, "Mod cost per frame: HUD %.2f ms | tick %.2f ms | blur %.2f ms",
                    Perf.hudMs, Perf.tickMs, Perf.blurMs);
            ctx.drawText(tr, tr.trimToWidth(t, areaW - 12), areaX + 6, y + 6, TEXT, false);
        }
        y += RH;
        if (visible(y)) ctx.drawText(tr, "Under ~1 ms = the mod is not what lowers your FPS.", areaX + 2, y + 2, 0xFF6C6C78, false);
        y += 14;
        return y;
    }

    private int pageKeybinds(DrawContext ctx, int y, int mx, int my) {
        keyRow(ctx, y, "Open menu", "menu", Config.cur.menuKey, v -> {
            if (v >= 0) Config.cur.menuKey = v;
            Config.saveCurrent();
        }, mx, my);
        y += RH;
        for (final Defs.Module d : Defs.ALL) {
            if (!d.impl) continue;
            final Config.Mod cm = Config.mod(d.id);
            keyRow(ctx, y, d.name + (d.id.equals("zoom") || d.id.equals("freelook") ? " (hold)" : d.id.equals("swap") ? " (run)" : " (toggle)"), d.id, cm.key, v -> {
                cm.key = v;
                Config.saveCurrent();
            }, mx, my);
            y += RH;
        }
        return y;
    }

    private int pageStyle(DrawContext ctx, int y, int mx, int my) {
        if (visible(y)) {
            row(ctx, y);
            ctx.drawText(tr, "HUD color", areaX + 8, y + 6, TEXT, false);
            int x = areaX + areaW - 6 - Config.COLOR_NAMES.length * 24;
            for (int i = 0; i < Config.COLOR_NAMES.length; i++) {
                final String cn = Config.COLOR_NAMES[i];
                boolean sel = Config.cur.hudColor.equals(cn);
                if (sel) Draw.rrect(ctx, x - 1, y + 2, 22, 16, 4, 0xFFFFFFFF);
                Draw.rrect(ctx, x, y + 3, 20, 14, 3, Config.COLOR_VALUES[i]);
                addHit(x, y + 3, 20, 14, () -> {
                    Config.cur.hudColor = cn;
                    Config.saveCurrent();
                }, null, null, 0, 0);
                x += 24;
            }
        }
        y += RH;
        sliderRow(ctx, y, "HUD opacity", 0.1, 1.0, 0.05, Config.cur.hudOpacity, v -> {
            Config.cur.hudOpacity = v;
            dirty = true;
        }, mx, my);
        y += RH;
        buttonRow(ctx, y, "Move HUD (drag elements)", () -> moveMode = true, mx, my);
        y += RH;
        return y;
    }

    private int pageMixins(DrawContext ctx, int y, int mx, int my) {
        String[][] names = {{"zoom", "Deep Zoom"}, {"cull", "Entity Culling"}, {"look", "Free Look"}, {"blur", "Motion Blur"}, {"armor", "Armor Hit Color"}};
        for (final String[] n : names) {
            String st = MixinState.status(n[0]);
            if (visible(y)) {
                row(ctx, y);
                ctx.drawText(tr, n[1], areaX + 8, y + 6, TEXT, false);
                int sc = st.equals("ACTIVE") ? GOOD : st.equals("BLOCKED") ? DANGER : DIM;
                ctx.drawText(tr, st, areaX + areaW - 4 - 64 - 6 - tr.getWidth(st), y + 6, sc, false);
                String label = st.equals("BLOCKED") ? "Retry" : st.equals("OFF") ? "Enable" : "Disable";
                button(ctx, areaX + areaW - 4 - 64, y + 2, 64, 16, label, 0xFF2A2A31, TEXT, mx, my, () -> {
                    if (st.equals("BLOCKED")) MixinState.retry(n[0]);
                    else MixinState.toggleOff(n[0]);
                }, null);
            }
            y += RH;
        }
        if (visible(y)) ctx.drawText(tr, "Restart the game to apply changes.", areaX + 2, y + 4, DIM, false);
        y += 13;
        if (visible(y)) ctx.drawText(tr, "If a start hangs, force close and open again:", areaX + 2, y + 2, DIM, false);
        y += 11;
        if (visible(y)) ctx.drawText(tr, "the bad part is blocked automatically.", areaX + 2, y + 2, DIM, false);
        y += 16;
        return y;
    }

    // ------------------------------------------------------------------ move HUD mode

    private void renderMove(DrawContext ctx, int mx, int my) {
        ctx.fill(0, 0, width, height, 0x33000000);
        for (Map.Entry<String, int[]> e : Hud.bounds.entrySet()) {
            int[] b = e.getValue();
            ctx.drawBorder(b[0] - 2, b[1] - 2, b[2] + 4, b[3] + 4, PURPLE);
        }
        ctx.drawCenteredTextWithShadow(tr, "Drag HUD elements", width / 2, 8, TEXT);
        button(ctx, width / 2 - 30, 22, 60, 18, "Done", GOOD, 0xFFFFFFFF, mx, my, () -> {
            moveMode = false;
            Config.saveCurrent();
        }, null);
    }

    // ================================================================== widgets

    private void beginClip(DrawContext ctx, int top) {
        ctx.enableScissor(areaX - 2, top, areaX + areaW + 2, areaY + areaH);
        clipY1 = top;
        clipY2 = areaY + areaH;
    }

    private void endClip(DrawContext ctx) {
        ctx.disableScissor();
        clipY1 = Integer.MIN_VALUE;
        clipY2 = Integer.MAX_VALUE;
    }

    private boolean visible(int y) {
        return y + 20 >= clipY1 && y <= clipY2;
    }

    private void addHit(int x, int y, int w, int h, Runnable left, Runnable right, DoubleConsumer drag, int trackX, int trackW) {
        int y1 = Math.max(y, clipY1);
        int y2 = Math.min(y + h, clipY2);
        if (y2 > y1) hits.add(new Hit(x, y1, w, y2 - y1, left, right, drag, trackX, trackW));
    }

    private void row(DrawContext ctx, int y) {
        Draw.card(ctx, areaX, y, areaW, 20, 5, CARD_BORDER, CARD);
    }

    private void button(DrawContext ctx, int x, int y, int w, int h, String label, int bg, int fg,
                        int mx, int my, Runnable left, Runnable right) {
        int y1 = Math.max(y, clipY1);
        int y2 = Math.min(y + h, clipY2);
        boolean vis = y2 > y1;
        boolean hover = vis && mx >= x && mx < x + w && my >= y1 && my < y2;
        Draw.rrect(ctx, x, y, w, h, 5, bg);
        if (hover) Draw.rrect(ctx, x, y, w, h, 5, 0x22FFFFFF);
        if (!label.isEmpty()) {
            String t = tr.trimToWidth(label, Math.max(4, w - 6));
            ctx.drawText(tr, t, x + (w - tr.getWidth(t)) / 2, y + (h - 8) / 2, fg, false);
        }
        if (left != null || right != null) addHit(x, y, w, h, left, right, null, 0, 0);
    }

    private void buttonRow(DrawContext ctx, int y, String label, Runnable action, int mx, int my) {
        if (!visible(y)) return;
        button(ctx, areaX, y, areaW, 20, label, 0xFF2A2A31, TEXT, mx, my, action, null);
    }

    private void toggleRow(DrawContext ctx, int y, String label, boolean val, Runnable flip, int mx, int my) {
        if (!visible(y)) return;
        row(ctx, y);
        ctx.drawText(tr, tr.trimToWidth(label, areaW - 50), areaX + 8, y + 6, TEXT, false);
        Draw.toggle(ctx, areaX + areaW - 30, y + 5, val, PURPLE);
        addHit(areaX + areaW - 33, y + 2, 29, 16, flip, null, null, 0, 0);
    }

    private void choiceRow(DrawContext ctx, int y, String label, String value, Runnable next, int mx, int my) {
        if (!visible(y)) return;
        row(ctx, y);
        ctx.drawText(tr, label, areaX + 8, y + 6, TEXT, false);
        button(ctx, areaX + areaW - 4 - 80, y + 2, 80, 16, value, 0xFF2A2A31, TEXT, mx, my, next, null);
    }

    private void keyRow(DrawContext ctx, int y, String label, Object token, int key, IntConsumer setter, int mx, int my) {
        if (!visible(y)) return;
        row(ctx, y);
        ctx.drawText(tr, tr.trimToWidth(label, areaW - 90), areaX + 8, y + 6, TEXT, false);
        boolean waiting = listenToken == token;
        String text = waiting ? "press key..." : Modules.keyName(key);
        button(ctx, areaX + areaW - 4 - 74, y + 2, 74, 16, text, waiting ? PURPLE : FIELD, waiting ? 0xFFFFFFFF : TEXT, mx, my,
                () -> {
                    listening = setter;
                    listenToken = token;
                },
                () -> {
                    setter.accept(-1);
                    Config.saveCurrent();
                });
    }

    private void sliderRow(DrawContext ctx, int y, String label, double min, double max, double step, double val,
                           DoubleConsumer setter, int mx, int my) {
        if (!visible(y)) return;
        row(ctx, y);
        ctx.drawText(tr, tr.trimToWidth(label, 100), areaX + 8, y + 6, TEXT, false);
        int tx = areaX + 118;
        int tw = areaW - 118 - 52;
        double frac = (val - min) / (max - min);
        frac = Math.max(0, Math.min(1, frac));
        Draw.rrect(ctx, tx, y + 8, tw, 4, 2, 0xFF33333B);
        Draw.rrect(ctx, tx, y + 8, Math.max(4, (int) (tw * frac)), 4, 2, PURPLE);
        Draw.rrect(ctx, tx + (int) (tw * frac) - 4, y + 5, 8, 10, 4, PURPLE_LIGHT);
        String vt = String.format(Locale.ROOT, step >= 1 ? "%.0f" : "%.2f", val);
        ctx.drawText(tr, vt, areaX + areaW - 8 - tr.getWidth(vt), y + 6, DIM, false);
        final double fmin = min;
        final double fmax = max;
        final double fstep = step;
        addHit(tx - 4, y + 2, tw + 8, 16, null, null, f -> {
            double v = fmin + f * (fmax - fmin);
            v = Math.round(v / fstep) * fstep;
            v = Math.max(fmin, Math.min(fmax, v));
            setter.accept(v);
        }, tx, tw);
    }

    private void textField(DrawContext ctx, int x, int y, int w, int h, Ref ref, Object token) {
        boolean active = editing != null && editToken == token;
        Draw.card(ctx, x, y, w, h, 4, active ? PURPLE : CARD_BORDER, FIELD);
        String s = active ? buf.toString() : ref.getter.get();
        String shown = tr.trimToWidth(s, Math.max(4, w - 10), active);
        if (active && (System.currentTimeMillis() / 500) % 2 == 0) shown = shown + "_";
        ctx.drawText(tr, shown, x + 4, y + (h - 8) / 2, TEXT, false);
        addHit(x, y, w, h, () -> startEdit(ref, token), null, null, 0, 0);
    }

    private void startEdit(Ref ref, Object token) {
        editing = ref;
        editToken = token;
        buf.setLength(0);
        buf.append(ref.getter.get());
    }

    private void stopEdit() {
        if (editing != null) {
            editing = null;
            editToken = null;
            Config.saveCurrent();
            Config.saveWaypoints();
        }
    }

    // ================================================================== input

    private boolean inPanel(double mx, double my) {
        return mx >= px && mx <= px + pw && my >= py && my <= py + ph;
    }

    private void applyDrag(Hit h, double mx) {
        double f = (mx - h.trackX) / (double) Math.max(1, h.trackW);
        h.drag.accept(Math.max(0, Math.min(1, f)));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        confirmArmed = confirmPending;
        confirmPending = false;
        stopEdit();
        listening = null;
        listenToken = null;

        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h) {
                if (button != 0 && button != 1) return true;
                if (h.drag != null) {
                    activeDrag = h;
                    applyDrag(h, mx);
                    return true;
                }
                Runnable r = button == 1 ? h.right : h.left;
                if (r != null) r.run();
                return true;
            }
        }

        if (moveMode || !inPanel(mx, my)) {
            String id = Hud.hit((int) mx, (int) my);
            if (id != null && button == 0) {
                Config.Mod m = Config.mod(id);
                int[] bb = Hud.bounds.get(id);
                if ((m.x < 0 || m.y < 0) && bb != null) {
                    m.x = bb[0];
                    m.y = bb[1];
                }
                dragId = id;
                dragOx = (int) mx - m.x;
                dragOy = (int) my - m.y;
            }
            return true;
        }

        if (button == 0 && mx >= areaX && mx <= areaX + areaW && my >= areaY && my <= areaY + areaH) {
            scrolling = true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragId != null) {
            Config.Mod m = Config.mod(dragId);
            m.x = Math.max(0, Math.min(width - 12, (int) mx - dragOx));
            m.y = Math.max(0, Math.min(height - 8, (int) my - dragOy));
            return true;
        }
        if (activeDrag != null) {
            applyDrag(activeDrag, mx);
            return true;
        }
        if (scrolling) {
            scroll -= (int) Math.round(dy);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        boolean was = dragId != null || activeDrag != null || scrolling || dirty;
        dragId = null;
        activeDrag = null;
        scrolling = false;
        if (dirty) {
            dirty = false;
        }
        if (was) Config.saveCurrent();
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (!moveMode) scroll -= (int) Math.signum(vertical) * RH;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                if (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) listening.accept(-1);
                else listening.accept(keyCode);
                Config.saveCurrent();
            }
            listening = null;
            listenToken = null;
            return true;
        }
        if (editing != null) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER || keyCode == GLFW.GLFW_KEY_ESCAPE) {
                stopEdit();
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (buf.length() > 0) {
                    buf.setLength(buf.length() - 1);
                    editing.setter.accept(buf.toString());
                }
            } else if (keyCode == GLFW.GLFW_KEY_V && (modifiers & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = MinecraftClient.getInstance().keyboard.getClipboard();
                if (clip != null) {
                    buf.append(clip.replace('\n', ' ').replace('\r', ' '));
                    if (buf.length() > 100) buf.setLength(100);
                    editing.setter.accept(buf.toString());
                }
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && (settingsFor != null || moveMode)) {
            settingsFor = null;
            moveMode = false;
            scroll = 0;
            return true;
        }
        if (keyCode == Config.cur.menuKey) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (editing != null) {
            if (chr >= 32 && chr != 127 && buf.length() < 100) {
                buf.append(chr);
                editing.setter.accept(buf.toString());
            }
            return true;
        }
        return super.charTyped(chr, modifiers);
    }
}
