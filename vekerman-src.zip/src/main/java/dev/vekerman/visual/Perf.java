package dev.vekerman.visual;

/** Tiny profiler: how many milliseconds per frame / tick the mod itself uses (shown in Config > Optimization). */
public class Perf {
    public static volatile double hudMs = 0;
    public static volatile double tickMs = 0;
    public static volatile double blurMs = 0;

    public static void hud(double ms) {
        hudMs = hudMs * 0.95 + ms * 0.05;
    }

    public static void tick(double ms) {
        tickMs = tickMs * 0.9 + ms * 0.1;
    }

    public static void blur(double ms) {
        blurMs = blurMs * 0.95 + ms * 0.05;
    }
}
