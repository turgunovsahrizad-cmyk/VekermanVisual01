package dev.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.render.ChunkBuilderMode;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticlesMode;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/** All the logic that makes modules work. Light: no mixins, only Fabric API events and public game fields. */
public class Modules {
    private static final Map<String, Boolean> prev = new HashMap<>();

    // ------------------------------------------------------------------ helpers

    public static String keyName(int code) {
        if (code < 0) return "None";
        try {
            return InputUtil.fromKeyCode(code, -1).getLocalizedText().getString();
        } catch (Exception e) {
            return "Key " + code;
        }
    }

    private static boolean edge(String id, int key, long handle) {
        if (key < 0) {
            prev.put(id, false);
            return false;
        }
        boolean now = InputUtil.isKeyPressed(handle, key);
        boolean was = prev.getOrDefault(id, false);
        prev.put(id, now);
        return now && !was;
    }

    public static void message(MinecraftClient mc, String s) {
        mc.inGameHud.setOverlayMessage(Text.literal(s), false);
    }

    public static int ping(MinecraftClient mc) {
        try {
            ClientPlayNetworkHandler h = mc.getNetworkHandler();
            if (h == null || mc.player == null) return 0;
            PlayerListEntry e = h.getPlayerListEntry(mc.player.getUuid());
            return e == null ? 0 : e.getLatency();
        } catch (Exception ex) {
            return 0;
        }
    }

    public static void runCommand(MinecraftClient mc, String raw) {
        if (mc.player == null || raw == null) return;
        String s = raw.trim();
        if (s.isEmpty() || s.equals("/")) return;
        if (s.startsWith("/")) mc.player.networkHandler.sendChatCommand(s.substring(1));
        else mc.player.networkHandler.sendChatMessage(s);
    }

    public static void armorSound(MinecraftClient mc) {
        mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 0.9f, 0.5f));
    }

    // ------------------------------------------------------------------ per tick

    private static int slowTimer = 0;

    public static void tick(MinecraftClient mc) {
        long t0 = System.nanoTime();
        try {
            tickInner(mc);
        } finally {
            Perf.tick((System.nanoTime() - t0) / 1.0e6);
        }
    }

    private static void tickInner(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            sprintForced = false;
            return;
        }
        long handle = mc.getWindow().getHandle();
        boolean inGame = mc.currentScreen == null;

        if (inGame) {
            if (edge("menu", Config.cur.menuKey, handle)) {
                mc.setScreen(new ClickGui());
                return;
            }
            for (Defs.Module d : Defs.ALL) {
                if (!d.impl) continue;
                Config.Mod m = Config.mod(d.id);
                if (d.id.equals("swap")) { // macro: the key runs it, it is not toggled
                    if (m.enabled && edge("m_swap", m.key, handle)) SwapMacro.trigger(mc);
                    continue;
                }
                if (edge("m_" + d.id, m.key, handle)) {
                    m.enabled = !m.enabled;
                    Config.saveCurrent();
                    message(mc, d.name + (m.enabled ? ": ON" : ": OFF"));
                }
            }
            for (Config.CmdBind c : Config.cur.cmds) {
                if (c.enabled && edge("cmd_" + System.identityHashCode(c), c.key, handle)) runCommand(mc, c.command);
            }
        } else {
            prev.clear();
        }

        sprint(mc, inGame);
        if (Config.on("pvpcount") && ++countTimer >= 5) {
            countTimer = 0;
            recount(mc);
        }

        if (--slowTimer <= 0) {
            slowTimer = 40; // every 2 seconds
            optimize(mc);
        }
        windowFocus(mc);
        memoryCleaner(mc);
    }

    /** called every frame */
    public static void frame(MinecraftClient mc, float dt) {
        SwapMacro.frame(mc);
    }

    // ------------------------------------------------------------------ auto sprint

    private static boolean sprintForced = false;

    private static void sprint(MinecraftClient mc, boolean inGame) {
        if (inGame && Config.on("autosprint") && mc.options.forwardKey.isPressed()) {
            mc.options.sprintKey.setPressed(true);
            sprintForced = true;
        } else if (sprintForced) {
            mc.options.sprintKey.setPressed(false);
            sprintForced = false;
        }
    }

    // ------------------------------------------------------------------ PvP counter (items in inventory + offhand)

    public static volatile int totems, gapples, pearls, potions;
    private static int countTimer = 0;

    private static void recount(MinecraftClient mc) {
        int t = 0, g = 0, p = 0, po = 0;
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            int n = s.getCount();
            if (s.isOf(Items.TOTEM_OF_UNDYING)) t += n;
            else if (s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE)) g += n;
            else if (s.isOf(Items.ENDER_PEARL)) p += n;
            else if (s.isOf(Items.SPLASH_POTION) || s.isOf(Items.POTION) || s.isOf(Items.LINGERING_POTION)) po += n;
        }
        totems = t;
        gapples = g;
        pearls = p;
        potions = po;
    }

    // ------------------------------------------------------------------ optimization

    private static class Orig {
        GraphicsMode graphics;
        CloudRenderMode clouds;
        boolean shadows;
        int biome;
        ParticlesMode particles;
        double entityDist;
        int maxFps;
        boolean vsync;
        ChunkBuilderMode chunk;
    }

    private static Orig orig = null;

    private static <T> void set(SimpleOption<T> opt, T value) {
        if (!opt.getValue().equals(value)) opt.setValue(value);
    }

    private static void optimize(MinecraftClient mc) {
        GameOptions o = mc.options;
        boolean boost = Config.on("fpsboost");
        boolean pOpt = Config.ob("particleOpt");
        boolean fast = Config.ob("fastChunk");
        boolean smooth = Config.ob("smoothFps");
        boolean any = boost || pOpt || fast || smooth;

        if (!any) {
            restoreOptions(mc);
            return;
        }
        if (orig == null) {
            Orig g = new Orig();
            g.graphics = o.getGraphicsMode().getValue();
            g.clouds = o.getCloudRenderMode().getValue();
            g.shadows = o.getEntityShadows().getValue();
            g.biome = o.getBiomeBlendRadius().getValue();
            g.particles = o.getParticles().getValue();
            g.entityDist = o.getEntityDistanceScaling().getValue();
            g.maxFps = lowered ? dynSaved : o.getMaxFps().getValue();
            g.vsync = o.getEnableVsync().getValue();
            g.chunk = o.getChunkBuilderMode().getValue();
            orig = g;
        }

        set(o.getGraphicsMode(), boost ? GraphicsMode.FAST : orig.graphics);
        set(o.getCloudRenderMode(), boost ? CloudRenderMode.OFF : orig.clouds);
        set(o.getEntityShadows(), boost ? Boolean.FALSE : Boolean.valueOf(orig.shadows));
        set(o.getBiomeBlendRadius(), boost ? Integer.valueOf(1) : Integer.valueOf(orig.biome));
        set(o.getEntityDistanceScaling(), boost ? Double.valueOf(0.75) : Double.valueOf(orig.entityDist));
        set(o.getChunkBuilderMode(), fast ? ChunkBuilderMode.NONE : orig.chunk);

        ParticlesMode pm;
        if (pOpt) {
            double lvl = Config.optn("particleLevel");
            pm = lvl > 66 ? ParticlesMode.ALL : lvl > 33 ? ParticlesMode.DECREASED : ParticlesMode.MINIMAL;
        } else {
            pm = boost ? ParticlesMode.DECREASED : orig.particles;
        }
        set(o.getParticles(), pm);

        if (smooth) {
            int cap = (int) Math.max(30, Math.min(240, Config.optn("fpsCap")));
            if (!lowered) set(o.getMaxFps(), Integer.valueOf(cap));
            else dynSaved = cap;
            set(o.getEnableVsync(), Boolean.FALSE);
        } else {
            if (!lowered) set(o.getMaxFps(), Integer.valueOf(orig.maxFps));
            else dynSaved = orig.maxFps;
            set(o.getEnableVsync(), Boolean.valueOf(orig.vsync));
        }
    }

    private static void restoreOptions(MinecraftClient mc) {
        if (orig == null) return;
        GameOptions o = mc.options;
        set(o.getGraphicsMode(), orig.graphics);
        set(o.getCloudRenderMode(), orig.clouds);
        set(o.getEntityShadows(), Boolean.valueOf(orig.shadows));
        set(o.getBiomeBlendRadius(), Integer.valueOf(orig.biome));
        set(o.getEntityDistanceScaling(), Double.valueOf(orig.entityDist));
        set(o.getChunkBuilderMode(), orig.chunk);
        set(o.getParticles(), orig.particles);
        if (!lowered) set(o.getMaxFps(), Integer.valueOf(orig.maxFps));
        set(o.getEnableVsync(), Boolean.valueOf(orig.vsync));
        orig = null;
    }

    // dynamic fps: very low frame rate while the game window is not focused (off by default)
    private static boolean lowered = false;
    private static int dynSaved = 120;

    private static void windowFocus(MinecraftClient mc) {
        SimpleOption<Integer> fps = mc.options.getMaxFps();
        if (Config.ob("dynamicFps") && !mc.isWindowFocused()) {
            if (!lowered) {
                dynSaved = fps.getValue();
                lowered = true;
            }
            if (fps.getValue() != 10) fps.setValue(10);
        } else if (lowered) {
            fps.setValue(dynSaved);
            lowered = false;
        }
    }

    // memory cleaner: only while a menu is open or the window is in the background, never during play (off by default)
    private static long lastGc = System.currentTimeMillis();

    private static void memoryCleaner(MinecraftClient mc) {
        if (!Config.ob("memoryCleaner")) return;
        long now = System.currentTimeMillis();
        if (now - lastGc > 120_000 && (mc.currentScreen != null || !mc.isWindowFocused())) {
            System.gc();
            lastGc = now;
        }
    }

    public static void settingsReplaced() {
        slowTimer = 0;
        prev.clear();
    }

    public static void shutdown(MinecraftClient mc) {
        restoreOptions(mc);
    }

    // ------------------------------------------------------------------ CPS

    private static final Deque<Long> lmbClicks = new ArrayDeque<>();
    private static final Deque<Long> rmbClicks = new ArrayDeque<>();
    private static boolean lmbDown = false;
    private static boolean rmbDown = false;

    public static void pollMouse(MinecraftClient mc) {
        long handle = mc.getWindow().getHandle();
        boolean active = mc.currentScreen == null && mc.player != null;
        boolean l = active && GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = active && GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (l && !lmbDown) lmbClicks.addLast(now);
        if (r && !rmbDown) rmbClicks.addLast(now);
        lmbDown = l;
        rmbDown = r;
        prune(lmbClicks, now);
        prune(rmbClicks, now);
    }

    private static void prune(Deque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
    }

    public static int cpsLeft() {
        return lmbClicks.size();
    }

    public static int cpsRight() {
        return rmbClicks.size();
    }
}
