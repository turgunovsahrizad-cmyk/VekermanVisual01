package dev.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.ChunkBuilderMode;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** All the logic that makes modules work. No mixins: only Fabric API events and public game fields. */
public class Modules {
    public static final int[] PALETTE = {
            0xFF55FFFF, 0xFFFF5555, 0xFF55FF55, 0xFFFFFF55, 0xFFFF55FF, 0xFFFFAA00, 0xFFFFFFFF
    };

    private static final Map<String, Boolean> prev = new HashMap<>();

    // ------------------------------------------------------------------ helpers

    public static String keyName(int code) {
        if (code < 0) return "None";
        try {
            return InputUtil.fromKeyCode(code, -1).getLocalizedText().getString();
        } catch (Exception e) {
            return "Key " + code;
        }
    }

    private static boolean edge(String id, int key, long handle) {
        if (key < 0) {
            prev.put(id, false);
            return false;
        }
        boolean now = InputUtil.isKeyPressed(handle, key);
        boolean was = prev.getOrDefault(id, false);
        prev.put(id, now);
        return now && !was;
    }

    public static void message(MinecraftClient mc, String s) {
        mc.inGameHud.setOverlayMessage(Text.literal(s), false);
    }

    public static String dimension(MinecraftClient mc) {
        return mc.world.getRegistryKey().getValue().toString();
    }

    public static int ping(MinecraftClient mc) {
        try {
            ClientPlayNetworkHandler h = mc.getNetworkHandler();
            if (h == null || mc.player == null) return 0;
            PlayerListEntry e = h.getPlayerListEntry(mc.player.getUuid());
            return e == null ? 0 : e.getLatency();
        } catch (Exception ex) {
            return 0;
        }
    }

    // ------------------------------------------------------------------ per tick

    private static int slowTimer = 0;

    private static boolean startupMarked = false;

    public static void tick(MinecraftClient mc) {
        long t0 = System.nanoTime();
        try {
            tickInner(mc);
        } finally {
            Perf.tick((System.nanoTime() - t0) / 1.0e6);
        }
    }

    private static void tickInner(MinecraftClient mc) {
        // title screen reached: this start was fine (see MixinState)
        if (!startupMarked && mc.getOverlay() == null && (mc.currentScreen != null || mc.world != null)) {
            startupMarked = true;
            MixinState.markSuccess();
        }
        if (mc.player == null || mc.world == null) {
            nvApplied = false;
            sprintForced = false;
            pending.clear();
            return;
        }
        long handle = mc.getWindow().getHandle();
        boolean inGame = mc.currentScreen == null;

        if (inGame) {
            if (edge("menu", Config.cur.menuKey, handle)) {
                mc.setScreen(new ClickGui());
                return;
            }
            for (Defs.Module d : Defs.ALL) {
                if (!d.impl || d.id.equals("zoom") || d.id.equals("freelook")) continue;
                Config.Mod m = Config.mod(d.id);
                if (d.id.equals("swap")) { // macro: the key runs it, it is not toggled
                    if (m.enabled && edge("m_swap", m.key, handle)) SwapMacro.trigger(mc);
                    continue;
                }
                if (edge("m_" + d.id, m.key, handle)) {
                    m.enabled = !m.enabled;
                    Config.saveCurrent();
                    message(mc, d.name + (m.enabled ? ": ON" : ": OFF"));
                }
            }
            // command binds
            for (Config.CmdBind c : Config.cur.cmds) {
                if (c.enabled && edge("cmd_" + System.identityHashCode(c), c.key, handle)) runCommand(mc, c.command);
            }
        } else {
            prev.clear();
        }

        sprint(mc, handle, inGame);
        fullbright(mc);
        damage(mc);

        if (--slowTimer <= 0) {
            slowTimer = 40; // every 2 seconds
            optimize(mc);
        }
        windowFocus(mc);
        memoryCleaner(mc);
    }

    // ------------------------------------------------------------------ command binds / sounds

    public static void runCommand(MinecraftClient mc, String raw) {
        if (mc.player == null || raw == null) return;
        String s = raw.trim();
        if (s.isEmpty() || s.equals("/")) return;
        if (s.startsWith("/")) mc.player.networkHandler.sendChatCommand(s.substring(1));
        else mc.player.networkHandler.sendChatMessage(s);
    }

    public static void armorSound(MinecraftClient mc) {
        mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 0.9f, 0.5f));
    }

    // ------------------------------------------------------------------ sprint

    private static boolean sprintForced = false;
    private static boolean sprintLatched = false;
    private static boolean sprintPrevPhys = false;

    private static boolean physicalSprint(MinecraftClient mc, long handle) {
        try {
            InputUtil.Key k = InputUtil.fromTranslationKey(mc.options.sprintKey.getBoundKeyTranslationKey());
            if (k.getCategory() == InputUtil.Type.KEYSYM) return InputUtil.isKeyPressed(handle, k.getCode());
        } catch (Exception e) {
            // unknown key type: ignore
        }
        return false;
    }

    private static void sprint(MinecraftClient mc, long handle, boolean inGame) {
        boolean forward = mc.options.forwardKey.isPressed();
        boolean force = false;

        boolean tog = inGame && Config.on("togglesprint") && Config.str("togglesprint", "mode").equals("Toggle");
        if (tog) {
            boolean phys = physicalSprint(mc, handle);
            if (phys && !sprintPrevPhys) sprintLatched = !sprintLatched;
            sprintPrevPhys = phys;
            if (sprintLatched && forward) force = true;
        } else {
            sprintLatched = false;
            sprintPrevPhys = false;
        }
        if (inGame && Config.on("autosprint") && forward) force = true;

        if (force) {
            mc.options.sprintKey.setPressed(true);
            sprintForced = true;
        } else if (sprintForced) {
            mc.options.sprintKey.setPressed(false);
            sprintForced = false;
        }
    }

    // ------------------------------------------------------------------ fullbright (client-side night vision)

    private static boolean nvApplied = false;

    private static void fullbright(MinecraftClient mc) {
        if (Config.on("fullbright")) {
            StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || !cur.isInfinite()) {
                mc.player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, StatusEffectInstance.INFINITE, 0, false, false, false));
            }
            nvApplied = true;
        } else if (nvApplied) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nvApplied = false;
        }
    }

    // ------------------------------------------------------------------ damage indicator

    private static class Pending {
        final LivingEntity e;
        final float hp;
        final long t;

        Pending(LivingEntity e, float hp, long t) {
            this.e = e;
            this.hp = hp;
            this.t = t;
        }
    }

    private static final Map<Integer, Pending> pending = new HashMap<>();

    public static ActionResult onAttack(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hit) {
        if (world.isClient && Config.on("damageindicator") && entity instanceof LivingEntity le) {
            pending.put(le.getId(), new Pending(le, le.getHealth(), System.currentTimeMillis()));
        }
        return ActionResult.PASS;
    }

    private static void damage(MinecraftClient mc) {
        if (pending.isEmpty()) return;
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<Integer, Pending>> it = pending.entrySet().iterator();
        while (it.hasNext()) {
            Pending p = it.next().getValue();
            float d = p.hp - p.e.getHealth();
            if (d > 0.01f) {
                Hud.damage.add(new Hud.Dmg(p.e.getPos().add(0, p.e.getHeight() * 0.9, 0), d, now));
                it.remove();
            } else if (now - p.t > 900 || p.e.isRemoved()) {
                it.remove();
            }
        }
    }

    // ------------------------------------------------------------------ zoom (smooth, per frame)

    private static double zoomCur = 1.0;
    private static double zoomStrength = 2.2;
    private static boolean zoomHeld = false;
    private static boolean zoomApplied = false;
    private static int baseFov = 70;
    private static int lastSlot = 0;
    private static boolean lookKeyPrev = false;
    private static boolean lookToggled = false;

    public static void frame(MinecraftClient mc, float dt) {
        SwapMacro.frame(mc);
        if (mc.player == null || mc.world == null) {
            restoreZoom(mc);
            return;
        }
        Config.Mod z = Config.mod("zoom");
        long handle = mc.getWindow().getHandle();
        boolean want = z.enabled && z.key >= 0 && mc.currentScreen == null && InputUtil.isKeyPressed(handle, z.key);

        if (want && !zoomHeld) {
            zoomHeld = true;
            if (!zoomApplied) baseFov = mc.options.getFov().getValue();
            zoomStrength = Config.num("zoom", "strength");
            lastSlot = mc.player.getInventory().selectedSlot;
        } else if (!want && zoomHeld) {
            zoomHeld = false;
        }

        if (zoomHeld) {
            // the mouse wheel changes the hotbar slot: use it to change zoom strength and undo the slot change
            int slot = mc.player.getInventory().selectedSlot;
            if (slot != lastSlot) {
                int delta = Math.floorMod(slot - lastSlot + 4, 9) - 4;
                zoomStrength -= delta * Config.num("zoom", "scroll");
                mc.player.getInventory().selectedSlot = lastSlot;
            }
            zoomStrength = Math.max(1.1, Math.min(10.0, zoomStrength));
        }

        // with the zoom mixin there is no limit; without it vanilla FOV can not go below 30
        boolean hooked = Hooks.fovHooked;
        double maxStrength = hooked ? 10.0 : Math.max(1.0, baseFov / 30.0);
        double target = zoomHeld ? Math.min(zoomStrength, maxStrength) : 1.0;
        double speed = Math.max(1.0, Config.num("zoom", "smooth"));
        zoomCur += (target - zoomCur) * (1.0 - Math.exp(-speed * dt));
        boolean zooming = zoomHeld || Math.abs(zoomCur - 1.0) > 0.004;
        Hooks.zoomFactor = (hooked && zooming) ? zoomCur : 1.0;

        if (hooked) {
            if (zoomApplied) {
                mc.options.getFov().setValue(baseFov);
                zoomApplied = false;
            }
        } else if (zooming) {
            int f = (int) Math.round(baseFov / zoomCur);
            f = Math.max(30, Math.min(110, f));
            zoomApplied = true;
            if (mc.options.getFov().getValue() != f) mc.options.getFov().setValue(f);
        } else if (zoomApplied) {
            mc.options.getFov().setValue(baseFov);
            zoomApplied = false;
            zoomCur = 1.0;
        }

        // free look: hold the key (or tap it in Toggle mode)
        Config.Mod lk = Config.mod("freelook");
        boolean keyDown = lk.enabled && lk.key >= 0 && mc.currentScreen == null
                && InputUtil.isKeyPressed(handle, lk.key);
        boolean wantLook;
        if (Config.str("freelook", "mode").equals("Toggle")) {
            if (keyDown && !lookKeyPrev) lookToggled = !lookToggled;
            if (!lk.enabled || mc.currentScreen != null) lookToggled = false;
            wantLook = lookToggled;
        } else {
            lookToggled = false;
            wantLook = keyDown;
        }
        if (keyDown && !lookKeyPrev && !Hooks.camHooked) {
            message(mc, "Free Look: camera hook is not active (Config > Mixins)");
        }
        lookKeyPrev = keyDown;
        if (wantLook && Hooks.camHooked && !FreeLook.active) {
            FreeLook.start(mc.player.getYaw(), mc.player.getPitch());
        } else if ((!wantLook || !Hooks.camHooked) && FreeLook.active) {
            FreeLook.stop();
        }
        if (FreeLook.active) FreeLook.absorb(mc.player);

        HitColor.update(mc);
    }

    private static void restoreZoom(MinecraftClient mc) {
        if (zoomApplied && mc.options != null) {
            mc.options.getFov().setValue(baseFov);
        }
        zoomApplied = false;
        zoomHeld = false;
        zoomCur = 1.0;
        Hooks.zoomFactor = 1.0;
        FreeLook.stop();
    }

    // ------------------------------------------------------------------ optimization

    private static class Orig {
        GraphicsMode graphics;
        CloudRenderMode clouds;
        boolean shadows;
        int biome;
        ParticlesMode particles;
        double entityDist;
        int maxFps;
        boolean vsync;
        ChunkBuilderMode chunk;
    }

    private static Orig orig = null;

    private static <T> void set(SimpleOption<T> opt, T value) {
        if (!opt.getValue().equals(value)) opt.setValue(value);
    }

    private static void optimize(MinecraftClient mc) {
        GameOptions o = mc.options;
        boolean boost = Config.on("fpsboost");
        boolean pOpt = Config.ob("particleOpt");
        boolean fast = Config.ob("fastChunk");
        boolean smooth = Config.ob("smoothFps");
        boolean any = boost || pOpt || fast || smooth;

        if (!any) {
            restoreOptions(mc);
            return;
        }
        if (orig == null) {
            Orig g = new Orig();
            g.graphics = o.getGraphicsMode().getValue();
            g.clouds = o.getCloudRenderMode().getValue();
            g.shadows = o.getEntityShadows().getValue();
            g.biome = o.getBiomeBlendRadius().getValue();
            g.particles = o.getParticles().getValue();
            g.entityDist = o.getEntityDistanceScaling().getValue();
            g.maxFps = lowered ? dynSaved : o.getMaxFps().getValue();
            g.vsync = o.getEnableVsync().getValue();
            g.chunk = o.getChunkBuilderMode().getValue();
            orig = g;
        }

        set(o.getGraphicsMode(), boost ? GraphicsMode.FAST : orig.graphics);
        set(o.getCloudRenderMode(), boost ? CloudRenderMode.OFF : orig.clouds);
        set(o.getEntityShadows(), boost ? Boolean.FALSE : Boolean.valueOf(orig.shadows));
        set(o.getBiomeBlendRadius(), boost ? Integer.valueOf(1) : Integer.valueOf(orig.biome));
        set(o.getEntityDistanceScaling(), boost ? Double.valueOf(0.75) : Double.valueOf(orig.entityDist));
        set(o.getChunkBuilderMode(), fast ? ChunkBuilderMode.NONE : orig.chunk);

        ParticlesMode pm;
        if (pOpt) {
            double lvl = Config.optn("particleLevel");
            pm = lvl > 66 ? ParticlesMode.ALL : lvl > 33 ? ParticlesMode.DECREASED : ParticlesMode.MINIMAL;
        } else {
            pm = boost ? ParticlesMode.DECREASED : orig.particles;
        }
        set(o.getParticles(), pm);

        if (smooth) {
            int cap = (int) Math.max(30, Math.min(240, Config.optn("fpsCap")));
            if (!lowered) set(o.getMaxFps(), Integer.valueOf(cap));
            else dynSaved = cap;
            set(o.getEnableVsync(), Boolean.FALSE);
        } else {
            if (!lowered) set(o.getMaxFps(), Integer.valueOf(orig.maxFps));
            else dynSaved = orig.maxFps;
            set(o.getEnableVsync(), Boolean.valueOf(orig.vsync));
        }
    }

    private static void restoreOptions(MinecraftClient mc) {
        if (orig == null) return;
        GameOptions o = mc.options;
        set(o.getGraphicsMode(), orig.graphics);
        set(o.getCloudRenderMode(), orig.clouds);
        set(o.getEntityShadows(), Boolean.valueOf(orig.shadows));
        set(o.getBiomeBlendRadius(), Integer.valueOf(orig.biome));
        set(o.getEntityDistanceScaling(), Double.valueOf(orig.entityDist));
        set(o.getChunkBuilderMode(), orig.chunk);
        set(o.getParticles(), orig.particles);
        if (!lowered) set(o.getMaxFps(), Integer.valueOf(orig.maxFps));
        set(o.getEnableVsync(), Boolean.valueOf(orig.vsync));
        orig = null;
    }

    // dynamic fps: very low frame rate while the game window is not focused / app is in the background
    private static boolean lowered = false;
    private static int dynSaved = 120;

    private static void windowFocus(MinecraftClient mc) {
        SimpleOption<Integer> fps = mc.options.getMaxFps();
        if (Config.ob("dynamicFps") && !mc.isWindowFocused()) {
            if (!lowered) {
                dynSaved = fps.getValue();
                lowered = true;
            }
            if (fps.getValue() != 10) fps.setValue(10);
        } else if (lowered) {
            fps.setValue(dynSaved);
            lowered = false;
        }
    }

    // memory cleaner: only runs while a menu is open or the window is in the background, so it never causes in-game lag
    private static long lastGc = System.currentTimeMillis();

    private static void memoryCleaner(MinecraftClient mc) {
        if (!Config.ob("memoryCleaner")) return;
        long now = System.currentTimeMillis();
        if (now - lastGc > 120_000 && (mc.currentScreen != null || !mc.isWindowFocused())) {
            System.gc();
            lastGc = now;
        }
    }

    // ------------------------------------------------------------------ settings replaced / shutdown

    public static void settingsReplaced() {
        slowTimer = 0;
        prev.clear();
    }

    public static void shutdown(MinecraftClient mc) {
        restoreZoom(mc);
        restoreOptions(mc);
    }

    // ------------------------------------------------------------------ CPS

    private static final Deque<Long> lmbClicks = new ArrayDeque<>();
    private static final Deque<Long> rmbClicks = new ArrayDeque<>();
    private static boolean lmbDown = false;
    private static boolean rmbDown = false;

    public static void pollMouse(MinecraftClient mc) {
        long handle = mc.getWindow().getHandle();
        boolean active = mc.currentScreen == null && mc.player != null;
        boolean l = active && GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = active && GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (l && !lmbDown) lmbClicks.addLast(now);
        if (r && !rmbDown) rmbClicks.addLast(now);
        lmbDown = l;
        rmbDown = r;
        prune(lmbClicks, now);
        prune(rmbClicks, now);
    }

    private static void prune(Deque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
    }

    public static int cpsLeft() {
        return lmbClicks.size();
    }

    public static int cpsRight() {
        return rmbClicks.size();
    }

    // ------------------------------------------------------------------ waypoints

    public static void addWaypoint(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        Config.Waypoint w = new Config.Waypoint();
        w.name = "Point " + (Config.waypoints.size() + 1);
        w.x = Math.floor(mc.player.getX());
        w.y = Math.floor(mc.player.getY());
        w.z = Math.floor(mc.player.getZ());
        w.dim = dimension(mc);
        w.color = PALETTE[Config.waypoints.size() % PALETTE.length];
        Config.waypoints.add(w);
        Config.saveWaypoints();
        message(mc, "Waypoint added: " + w.name);
    }
}
