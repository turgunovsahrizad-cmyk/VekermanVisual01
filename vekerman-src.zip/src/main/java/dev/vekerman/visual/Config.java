package dev.vekerman.visual;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class Config {
    public static class Mod {
        public boolean enabled;
        public int key = -1;
        public int x;
        public int y;
        public Map<String, Double> n = new LinkedHashMap<>();
        public Map<String, String> s = new LinkedHashMap<>();
    }

    public static class CmdBind {
        public String command = "/";
        public int key = -1;
        public boolean enabled = true;
    }

    public static class Settings {
        public int ver = 0;
        public List<CmdBind> cmds = new ArrayList<>();
        public Map<String, Mod> mods = new LinkedHashMap<>();
        public Map<String, Boolean> optb = new LinkedHashMap<>();
        public Map<String, Double> optn = new LinkedHashMap<>();
        public String hudColor = "Purple";
        public double hudOpacity = 0.6;
        public int menuKey = 344; // Right Shift
    }

    public static final String[] COLOR_NAMES = {"Purple", "Blue", "Green", "Red", "Orange", "White"};
    public static final int[] COLOR_VALUES = {0xFF8B5CF6, 0xFF3B82F6, 0xFF22C55E, 0xFFEF4444, 0xFFF97316, 0xFFFFFFFF};

    private static final Logger LOG = LoggerFactory.getLogger("VekermanVisual");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Settings cur = new Settings();

    // ---------------------------------------------------------------- paths

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("VekermanVisual");
    }

    public static Path configsDir() {
        return dir().resolve("configs");
    }

    // ---------------------------------------------------------------- accessors

    public static Mod mod(String id) {
        return cur.mods.computeIfAbsent(id, k -> newMod(k));
    }

    public static boolean on(String id) {
        return mod(id).enabled;
    }

    public static double num(String id, String key) {
        Mod m = mod(id);
        Double v = m.n.get(key);
        if (v != null) return v;
        Defs.Module d = Defs.find(id);
        if (d != null) {
            Defs.Setting s = d.setting(key);
            if (s != null) return s.def;
        }
        return 0;
    }

    public static boolean flag(String id, String key) {
        return num(id, key) > 0.5;
    }

    public static String str(String id, String key) {
        Mod m = mod(id);
        String v = m.s.get(key);
        if (v != null) return v;
        Defs.Module d = Defs.find(id);
        if (d != null) {
            Defs.Setting s = d.setting(key);
            if (s != null && s.opts != null) return s.opts[(int) s.def];
        }
        return "";
    }

    public static boolean ob(String k) {
        Boolean b = cur.optb.get(k);
        return b != null && b;
    }

    public static double optn(String k) {
        Double d = cur.optn.get(k);
        return d == null ? 0 : d;
    }

    public static int accent() {
        for (int i = 0; i < COLOR_NAMES.length; i++) if (COLOR_NAMES[i].equals(cur.hudColor)) return COLOR_VALUES[i];
        return COLOR_VALUES[0];
    }

    // ---------------------------------------------------------------- defaults

    private static Mod newMod(String id) {
        Mod m = new Mod();
        Defs.Module d = Defs.find(id);
        if (d != null) {
            m.enabled = d.defOn;
            m.key = d.defKey;
            m.x = d.dx;
            m.y = d.dy;
        }
        return m;
    }

    public static Settings defaults() {
        Settings s = new Settings();
        ensureDefaults(s);
        return s;
    }

    public static void ensureDefaults(Settings s) {
        if (s.mods == null) s.mods = new LinkedHashMap<>();
        if (s.optb == null) s.optb = new LinkedHashMap<>();
        if (s.optn == null) s.optn = new LinkedHashMap<>();
        if (s.hudColor == null) s.hudColor = "Purple";
        if (s.cmds == null) s.cmds = new ArrayList<>();
        for (Defs.Module d : Defs.ALL) if (!s.mods.containsKey(d.id)) s.mods.put(d.id, newMod(d.id));
        s.optb.putIfAbsent("dynamicFps", false);
        s.optb.putIfAbsent("fastChunk", true);
        s.optb.putIfAbsent("particleOpt", true);
        s.optb.putIfAbsent("smoothFps", false);
        s.optb.putIfAbsent("memoryCleaner", false);
        s.optn.putIfAbsent("particleLevel", 50.0);
        s.optn.putIfAbsent("fpsCap", 120.0);
        if (s.ver < 3) { // these two depend on window focus, which Android does not report reliably: off by default
            s.optb.put("dynamicFps", false);
            s.optb.put("memoryCleaner", false);
            s.ver = 3;
        }
    }

    // ---------------------------------------------------------------- current config

    public static void init() {
        try {
            Files.createDirectories(configsDir());
        } catch (Exception e) {
            LOG.warn("Could not create config folders", e);
        }
        Settings s = read(dir().resolve("current.json"));
        if (s == null) {
            s = defaults();
            // FPS Boost is on by default (already set in Defs)
        }
        cur = s;
        saveCurrent();
    }

    public static void saveCurrent() {
        write(dir().resolve("current.json"), cur);
    }

    private static Settings read(Path p) {
        try {
            if (!Files.exists(p)) return null;
            try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                Settings s = GSON.fromJson(r, Settings.class);
                if (s == null) return null;
                ensureDefaults(s);
                return s;
            }
        } catch (Exception e) {
            LOG.warn("Could not read " + p, e);
            return null;
        }
    }

    private static void write(Path p, Object o) {
        try {
            Files.createDirectories(p.getParent());
            try (Writer w = Files.newBufferedWriter(p, StandardCharsets.UTF_8)) {
                GSON.toJson(o, w);
            }
        } catch (Exception e) {
            LOG.warn("Could not write " + p, e);
        }
    }

    // ---------------------------------------------------------------- profiles

    public static String safeName(String raw) {
        String n = raw == null ? "" : raw.trim().replaceAll("[^A-Za-z0-9_\\- ]", "_");
        if (n.length() > 32) n = n.substring(0, 32);
        return n;
    }

    public static List<String> listProfiles() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> st = Files.list(configsDir())) {
            st.forEach(p -> {
                String f = p.getFileName().toString();
                if (f.endsWith(".json")) out.add(f.substring(0, f.length() - 5));
            });
        } catch (Exception e) {
            // folder missing: nothing to list
        }
        Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    public static boolean saveProfile(String name) {
        String n = safeName(name);
        if (n.isEmpty()) return false;
        write(configsDir().resolve(n + ".json"), cur);
        return true;
    }

    public static boolean loadProfile(String name) {
        Settings s = read(configsDir().resolve(safeName(name) + ".json"));
        if (s == null) return false;
        cur = s;
        saveCurrent();
        Modules.settingsReplaced();
        return true;
    }

    public static void deleteProfile(String name) {
        try {
            Files.deleteIfExists(configsDir().resolve(safeName(name) + ".json"));
        } catch (Exception e) {
            LOG.warn("Could not delete profile", e);
        }
    }

    public static void applySettings(Settings s) {
        ensureDefaults(s);
        cur = s;
        saveCurrent();
        Modules.settingsReplaced();
    }
}
