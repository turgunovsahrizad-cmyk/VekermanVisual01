package dev.vekerman.visual;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

public class VekermanVisual implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Config.init(); // creates VekermanVisual/ and VekermanVisual/configs/ on first launch

        ClientTickEvents.END_CLIENT_TICK.register(Modules::tick);
        HudRenderCallback.EVENT.register(Hud::render);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            Modules.shutdown(client);
            Config.saveCurrent();
        });

        // /vk or /vekerman opens the menu (handy on phones without a Right Shift key)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            registerOpen(dispatcher, "vk");
            registerOpen(dispatcher, "vekerman");
        });
    }

    private static void registerOpen(CommandDispatcher<FabricClientCommandSource> dispatcher, String name) {
        dispatcher.register(ClientCommandManager.literal(name).executes(context -> {
            MinecraftClient mc = context.getSource().getClient();
            mc.send(() -> mc.setScreen(new ClickGui()));
            return 1;
        }));
    }
}
