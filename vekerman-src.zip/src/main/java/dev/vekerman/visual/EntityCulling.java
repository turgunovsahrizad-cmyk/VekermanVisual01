package dev.vekerman.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.HashMap;
import java.util.Map;

/** Skips rendering of entities that are completely hidden behind blocks. Results are cached for a few ticks. */
public class EntityCulling {
    private static final Map<Integer, long[]> cache = new HashMap<>(); // id -> {recheckAtTick, hidden}

    public static boolean shouldHide(Entity e) {
        try {
            if (!Config.on("entityculling")) return false;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world == null || mc.player == null || e == mc.player || e == mc.cameraEntity) return false;
            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            if (e.getPos().distanceTo(cam) < Config.num("entityculling", "mindist")) return false;

            long now = mc.world.getTime();
            long[] c = cache.get(e.getId());
            if (c != null && now < c[0]) return c[1] == 1;

            boolean visible = visible(mc, cam, e);
            if (cache.size() > 3000) cache.clear();
            cache.put(e.getId(), new long[]{now + 4 + (e.getId() & 3), visible ? 0 : 1});
            return !visible;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean visible(MinecraftClient mc, Vec3d cam, Entity e) {
        Box b = e.getBoundingBox();
        Vec3d c = b.getCenter();
        Vec3d[] pts = {c, new Vec3d(c.x, b.maxY, c.z), new Vec3d(c.x, b.minY + 0.1, c.z)};
        for (Vec3d p : pts) {
            RaycastContext ctx = new RaycastContext(cam, p, RaycastContext.ShapeType.VISUAL,
                    RaycastContext.FluidHandling.NONE, mc.player);
            if (mc.world.raycast(ctx).getType() == HitResult.Type.MISS) return true;
        }
        return false;
    }
}
